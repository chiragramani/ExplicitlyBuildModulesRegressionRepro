import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST850",
    targets: [
        makeLibraryTarget(name: "ST850", dependencies: ["ST44", "ST26", "ST4", "ST74", "ST531", "ST38", "ST530", "ST20", "ST96", "ST102", "ST192"])
    ]
)