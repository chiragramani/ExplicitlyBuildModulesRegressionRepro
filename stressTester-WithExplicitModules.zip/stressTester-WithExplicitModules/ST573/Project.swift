import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST573",
    targets: [
        makeLibraryTarget(name: "ST573", dependencies: ["ST518", "ST187", "ST87", "ST178", "ST26", "ST131", "ST74", "ST138", "ST495", "ST515", "ST177", "ST89", "ST139", "ST20", "ST516", "ST70", "ST102", "ST144", "ST92", "ST62"])
    ]
)