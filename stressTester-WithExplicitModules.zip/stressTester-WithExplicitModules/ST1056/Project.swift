import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1056",
    targets: [
        makeLibraryTarget(name: "ST1056", dependencies: ["ST38", "ST44"])
    ]
)