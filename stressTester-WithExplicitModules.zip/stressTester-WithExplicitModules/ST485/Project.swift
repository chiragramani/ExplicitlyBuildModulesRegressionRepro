import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST485",
    targets: [
        makeLibraryTarget(name: "ST485", dependencies: ["ST92", "ST26", "ST97", "ST87", "ST74", "ST487", "ST151", "ST89", "ST4", "ST170", "ST70", "ST96", "ST15", "ST167", "ST162", "ST38", "ST20", "ST102"])
    ]
)