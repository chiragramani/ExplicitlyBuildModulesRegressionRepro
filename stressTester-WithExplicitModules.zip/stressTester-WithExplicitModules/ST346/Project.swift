import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST346",
    targets: [
        makeLibraryTarget(name: "ST346", dependencies: ["ST26", "ST27", "ST189", "ST44", "ST192", "ST536", "ST535", "ST596", "ST4", "ST80", "ST138", "ST38"])
    ]
)