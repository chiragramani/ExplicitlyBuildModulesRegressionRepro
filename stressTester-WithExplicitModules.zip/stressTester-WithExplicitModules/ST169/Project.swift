import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST169",
    targets: [
        makeLibraryTarget(name: "ST169", dependencies: ["ST96", "ST92", "ST26"])
    ]
)