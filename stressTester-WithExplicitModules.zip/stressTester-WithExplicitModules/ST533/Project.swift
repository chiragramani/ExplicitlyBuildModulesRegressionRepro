import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST533",
    targets: [
        makeLibraryTarget(name: "ST533", dependencies: ["ST92", "ST592", "ST102", "ST593", "ST214"])
    ]
)