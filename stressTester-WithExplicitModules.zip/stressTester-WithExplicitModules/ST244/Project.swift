import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST244",
    targets: [
        makeLibraryTarget(name: "ST244", dependencies: ["ST214", "ST68", "ST96", "ST92", "ST690", "ST489", "ST26", "ST74"])
    ]
)