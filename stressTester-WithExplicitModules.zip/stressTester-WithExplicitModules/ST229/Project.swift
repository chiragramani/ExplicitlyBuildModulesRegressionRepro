import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST229",
    targets: [
        makeLibraryTarget(name: "ST229", dependencies: ["ST20", "ST89", "ST19", "ST92", "ST96", "ST61", "ST102", "ST26", "ST71", "ST38", "ST74"])
    ]
)