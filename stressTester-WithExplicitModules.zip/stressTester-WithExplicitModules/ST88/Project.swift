import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST88",
    targets: [
        makeLibraryTarget(name: "ST88", dependencies: [])
    ]
)