import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST325",
    targets: [
        makeLibraryTarget(name: "ST325", dependencies: ["ST74", "ST154", "ST159", "ST131", "ST626", "ST138", "ST51", "ST20", "ST422", "ST23", "ST27", "ST627", "ST10", "ST16", "ST150", "ST40", "ST102", "ST156", "ST136", "ST54", "ST63", "ST161", "ST628", "ST56", "ST70", "ST26", "ST89", "ST38", "ST96", "ST4", "ST187", "ST92"])
    ]
)