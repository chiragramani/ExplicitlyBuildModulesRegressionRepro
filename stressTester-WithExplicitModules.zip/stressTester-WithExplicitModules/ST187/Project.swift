import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST187",
    targets: [
        makeLibraryTarget(name: "ST187", dependencies: ["ST4", "ST74", "ST96", "ST834", "ST65", "ST201", "ST26", "ST738", "ST93", "ST519", "ST807", "ST806", "ST44", "ST37", "ST190"])
    ]
)