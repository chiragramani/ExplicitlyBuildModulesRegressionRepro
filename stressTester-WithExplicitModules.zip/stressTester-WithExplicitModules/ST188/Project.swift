import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST188",
    targets: [
        makeLibraryTarget(name: "ST188", dependencies: ["ST138", "ST23"])
    ]
)