import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST829",
    targets: [
        makeLibraryTarget(name: "ST829", dependencies: ["ST830", "ST96"])
    ]
)