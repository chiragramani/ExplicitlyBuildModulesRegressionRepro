import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST470",
    targets: [
        makeLibraryTarget(name: "ST470", dependencies: ["ST793", "ST195", "ST529", "ST192", "ST61", "ST92", "ST88", "ST530", "ST96", "ST87", "ST99", "ST162", "ST4", "ST666", "ST187", "ST524", "ST89", "ST70", "ST600", "ST100", "ST44", "ST742", "ST267", "ST196", "ST740", "ST590", "ST37", "ST214", "ST38", "ST531", "ST794", "ST155", "ST731", "ST468", "ST225", "ST430", "ST68", "ST273", "ST20", "ST95", "ST26", "ST102", "ST54", "ST429", "ST768", "ST250", "ST74", "ST469"])
    ]
)