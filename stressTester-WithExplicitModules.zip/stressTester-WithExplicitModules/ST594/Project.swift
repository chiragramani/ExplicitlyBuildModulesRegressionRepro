import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST594",
    targets: [
        makeLibraryTarget(name: "ST594", dependencies: ["ST478", "ST20", "ST131", "ST603", "ST92", "ST60", "ST484", "ST54", "ST74", "ST4", "ST70", "ST454", "ST26", "ST96", "ST479", "ST275", "ST89", "ST102", "ST483"])
    ]
)