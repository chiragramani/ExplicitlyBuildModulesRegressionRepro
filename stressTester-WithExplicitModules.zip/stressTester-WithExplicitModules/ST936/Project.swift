import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST936",
    targets: [
        makeLibraryTarget(name: "ST936", dependencies: ["ST44", "ST38"])
    ]
)