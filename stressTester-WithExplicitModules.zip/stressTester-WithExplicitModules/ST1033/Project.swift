import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1033",
    targets: [
        makeLibraryTarget(name: "ST1033", dependencies: ["ST38", "ST44"])
    ]
)