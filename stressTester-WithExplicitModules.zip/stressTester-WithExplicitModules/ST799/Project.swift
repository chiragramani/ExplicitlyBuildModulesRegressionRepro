import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST799",
    targets: [
        makeLibraryTarget(name: "ST799", dependencies: [])
    ]
)