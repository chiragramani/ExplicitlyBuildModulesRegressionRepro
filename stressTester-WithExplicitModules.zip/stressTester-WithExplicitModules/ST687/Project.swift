import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST687",
    targets: [
        makeLibraryTarget(name: "ST687", dependencies: ["ST675", "ST244", "ST92", "ST96", "ST89", "ST26", "ST68", "ST38", "ST214", "ST667", "ST195", "ST651", "ST707"])
    ]
)