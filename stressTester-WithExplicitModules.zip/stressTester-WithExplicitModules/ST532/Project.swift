import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST532",
    targets: [
        makeLibraryTarget(name: "ST532", dependencies: ["ST195", "ST26"])
    ]
)