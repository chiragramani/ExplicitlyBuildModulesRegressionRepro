import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST527",
    targets: [
        makeLibraryTarget(name: "ST527", dependencies: ["ST490", "ST489", "ST26", "ST92"])
    ]
)