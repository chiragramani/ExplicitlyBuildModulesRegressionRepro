import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1115",
    targets: [
        makeLibraryTarget(name: "ST1115", dependencies: ["ST38", "ST44"])
    ]
)