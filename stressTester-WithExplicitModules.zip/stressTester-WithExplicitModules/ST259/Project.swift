import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST259",
    targets: [
        makeLibraryTarget(name: "ST259", dependencies: ["ST225", "ST89", "ST74", "ST68", "ST611", "ST102", "ST20", "ST187", "ST186", "ST253", "ST220", "ST4", "ST96", "ST841", "ST524", "ST646", "ST587", "ST214", "ST25", "ST690", "ST18", "ST92", "ST26"])
    ]
)