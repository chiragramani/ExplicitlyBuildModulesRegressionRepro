import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1125",
    targets: [
        makeLibraryTarget(name: "ST1125", dependencies: ["ST38", "ST44"])
    ]
)