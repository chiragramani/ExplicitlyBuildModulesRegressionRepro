import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST888",
    targets: [
        makeLibraryTarget(name: "ST888", dependencies: [])
    ]
)