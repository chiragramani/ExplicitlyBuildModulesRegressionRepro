import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST873",
    targets: [
        makeLibraryTarget(name: "ST873", dependencies: ["ST38", "ST44"])
    ]
)