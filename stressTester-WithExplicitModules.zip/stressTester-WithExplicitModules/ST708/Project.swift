import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST708",
    targets: [
        makeLibraryTarget(name: "ST708", dependencies: ["ST489", "ST80", "ST38", "ST44", "ST26", "ST4", "ST192", "ST709"])
    ]
)