import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1164",
    targets: [
        makeLibraryTarget(name: "ST1164", dependencies: ["ST44", "ST38"])
    ]
)