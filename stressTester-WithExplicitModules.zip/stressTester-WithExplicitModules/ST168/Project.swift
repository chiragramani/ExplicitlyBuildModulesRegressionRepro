import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST168",
    targets: [
        makeLibraryTarget(name: "ST168", dependencies: ["ST97", "ST29", "ST190", "ST195", "ST37", "ST48", "ST718", "ST92", "ST74", "ST170", "ST161", "ST187", "ST38", "ST96", "ST4", "ST26"])
    ]
)