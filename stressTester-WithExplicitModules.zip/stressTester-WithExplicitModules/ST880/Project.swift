import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST880",
    targets: [
        makeLibraryTarget(name: "ST880", dependencies: ["ST26", "ST74", "ST48", "ST96", "ST1144"])
    ]
)