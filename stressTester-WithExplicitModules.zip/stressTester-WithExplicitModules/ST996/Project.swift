import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST996",
    targets: [
        makeLibraryTarget(name: "ST996", dependencies: ["ST38", "ST44"])
    ]
)