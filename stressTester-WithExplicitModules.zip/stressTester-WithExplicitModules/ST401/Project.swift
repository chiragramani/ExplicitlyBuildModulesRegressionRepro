import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST401",
    targets: [
        makeLibraryTarget(name: "ST401", dependencies: ["ST70", "ST26", "ST29", "ST162", "ST54", "ST195", "ST253", "ST142", "ST225", "ST44", "ST138", "ST87", "ST96", "ST74", "ST214", "ST154", "ST68", "ST267", "ST529", "ST131", "ST92", "ST400", "ST12", "ST89", "ST161", "ST102", "ST20", "ST4", "ST610", "ST611", "ST259", "ST532", "ST37", "ST38"])
    ]
)