import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST261",
    targets: [
        makeLibraryTarget(name: "ST261", dependencies: ["ST96", "ST25", "ST530", "ST79", "ST214", "ST54", "ST92", "ST249", "ST250", "ST81", "ST38", "ST535", "ST171", "ST489", "ST18", "ST11", "ST187", "ST102", "ST532", "ST44", "ST24", "ST195", "ST244", "ST223", "ST531", "ST37", "ST26", "ST70", "ST802", "ST270", "ST74", "ST68", "ST192", "ST703", "ST161", "ST20", "ST439", "ST4", "ST589", "ST89", "ST819", "ST87", "ST524"])
    ]
)