import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST997",
    targets: [
        makeLibraryTarget(name: "ST997", dependencies: ["ST38", "ST44"])
    ]
)