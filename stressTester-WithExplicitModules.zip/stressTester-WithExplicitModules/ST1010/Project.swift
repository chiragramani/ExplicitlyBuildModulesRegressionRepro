import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1010",
    targets: [
        makeLibraryTarget(name: "ST1010", dependencies: ["ST44", "ST38"])
    ]
)