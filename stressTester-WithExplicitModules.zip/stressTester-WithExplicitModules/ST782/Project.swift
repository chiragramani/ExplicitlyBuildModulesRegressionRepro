import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST782",
    targets: [
        makeLibraryTarget(name: "ST782", dependencies: ["ST792", "ST186", "ST590", "ST253", "ST89", "ST102", "ST68", "ST18", "ST20", "ST92", "ST593", "ST533", "ST4", "ST657", "ST25", "ST690", "ST214", "ST26", "ST96", "ST278", "ST587", "ST74", "ST23", "ST162", "ST666", "ST524"])
    ]
)