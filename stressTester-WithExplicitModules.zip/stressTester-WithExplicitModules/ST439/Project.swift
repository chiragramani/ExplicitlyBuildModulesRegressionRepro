import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST439",
    targets: [
        makeLibraryTarget(name: "ST439", dependencies: ["ST74", "ST44", "ST38", "ST92", "ST96", "ST163", "ST4"])
    ]
)