import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1109",
    targets: [
        makeLibraryTarget(name: "ST1109", dependencies: ["ST38", "ST44"])
    ]
)