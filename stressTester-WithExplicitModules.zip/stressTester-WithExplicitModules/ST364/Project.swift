import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST364",
    targets: [
        makeLibraryTarget(name: "ST364", dependencies: ["ST418", "ST187", "ST635", "ST70", "ST154", "ST44", "ST142", "ST90", "ST757", "ST131", "ST85", "ST76", "ST758", "ST24", "ST87", "ST96", "ST92", "ST441", "ST759", "ST26", "ST64", "ST453", "ST134", "ST61", "ST760", "ST535", "ST138", "ST38", "ST20", "ST74", "ST553", "ST102", "ST37", "ST192", "ST4", "ST150", "ST81", "ST148", "ST89"])
    ]
)