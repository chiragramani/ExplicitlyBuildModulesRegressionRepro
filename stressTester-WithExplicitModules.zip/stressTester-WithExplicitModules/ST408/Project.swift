import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST408",
    targets: [
        makeLibraryTarget(name: "ST408", dependencies: ["ST26", "ST23", "ST250", "ST92", "ST509", "ST90", "ST54", "ST284", "ST24", "ST61", "ST62", "ST222", "ST89", "ST573", "ST44", "ST207", "ST96", "ST380", "ST38", "ST154", "ST213", "ST20", "ST417", "ST45", "ST195", "ST310", "ST102", "ST70", "ST323", "ST390", "ST330", "ST148", "ST187", "ST223", "ST4", "ST29", "ST194", "ST67", "ST74", "ST68", "ST364", "ST350", "ST76", "ST39", "ST11", "ST136", "ST140", "ST418", "ST189", "ST319", "ST313", "ST303", "ST138", "ST27", "ST134", "ST43", "ST37", "ST98", "ST142", "ST192", "ST196", "ST153", "ST450", "ST131", "ST150", "ST535", "ST81", "ST58", "ST287"])
    ]
)