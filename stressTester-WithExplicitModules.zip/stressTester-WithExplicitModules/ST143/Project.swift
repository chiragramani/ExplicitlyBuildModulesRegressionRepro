import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST143",
    targets: [
        makeLibraryTarget(name: "ST143", dependencies: ["ST178", "ST38", "ST140", "ST92", "ST23", "ST131", "ST26", "ST27", "ST753", "ST74", "ST138", "ST96"])
    ]
)