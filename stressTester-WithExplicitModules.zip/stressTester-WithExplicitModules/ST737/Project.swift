import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST737",
    targets: [
        makeLibraryTarget(name: "ST737", dependencies: ["ST192", "ST102", "ST37", "ST44", "ST70", "ST74", "ST38", "ST26", "ST96", "ST4", "ST89", "ST20", "ST186", "ST738", "ST161", "ST92"])
    ]
)