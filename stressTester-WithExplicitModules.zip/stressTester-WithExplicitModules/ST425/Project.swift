import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST425",
    targets: [
        makeLibraryTarget(name: "ST425", dependencies: ["ST513", "ST179", "ST495", "ST96", "ST4", "ST74", "ST178", "ST192", "ST26", "ST48", "ST20", "ST27", "ST271", "ST23", "ST92", "ST191", "ST452"])
    ]
)