import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST999",
    targets: [
        makeLibraryTarget(name: "ST999", dependencies: ["ST44", "ST38"])
    ]
)