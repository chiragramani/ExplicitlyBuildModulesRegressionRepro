import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST913",
    targets: [
        makeLibraryTarget(name: "ST913", dependencies: ["ST38", "ST44"])
    ]
)