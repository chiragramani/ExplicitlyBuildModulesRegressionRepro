import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST424",
    targets: [
        makeLibraryTarget(name: "ST424", dependencies: ["ST74", "ST720", "ST44", "ST38", "ST769", "ST837", "ST48", "ST26"])
    ]
)