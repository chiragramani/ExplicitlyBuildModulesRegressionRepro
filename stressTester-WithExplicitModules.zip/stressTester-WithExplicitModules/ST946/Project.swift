import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST946",
    targets: [
        makeLibraryTarget(name: "ST946", dependencies: ["ST38", "ST44"])
    ]
)