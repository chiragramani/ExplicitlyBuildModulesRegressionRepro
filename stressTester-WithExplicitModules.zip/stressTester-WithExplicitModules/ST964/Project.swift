import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST964",
    targets: [
        makeLibraryTarget(name: "ST964", dependencies: ["ST38", "ST44"])
    ]
)