import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST998",
    targets: [
        makeLibraryTarget(name: "ST998", dependencies: ["ST38", "ST44"])
    ]
)