import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST947",
    targets: [
        makeLibraryTarget(name: "ST947", dependencies: ["ST44", "ST38"])
    ]
)