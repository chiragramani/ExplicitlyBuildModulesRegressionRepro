import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1176",
    targets: [
        makeLibraryTarget(name: "ST1176", dependencies: ["ST1177", "ST1175"])
    ]
)