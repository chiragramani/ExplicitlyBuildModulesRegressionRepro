import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST881",
    targets: [
        makeLibraryTarget(name: "ST881", dependencies: [])
    ]
)