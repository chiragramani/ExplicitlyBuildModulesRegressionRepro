import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST477",
    targets: [
        makeLibraryTarget(name: "ST477", dependencies: ["ST80", "ST96", "ST99", "ST20", "ST532", "ST92", "ST74", "ST89", "ST38", "ST4", "ST70", "ST26", "ST102", "ST44", "ST87"])
    ]
)