import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST145",
    targets: [
        makeLibraryTarget(name: "ST145", dependencies: ["ST102", "ST194", "ST27", "ST176", "ST62", "ST26", "ST516", "ST138", "ST175", "ST92"])
    ]
)