import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST826",
    targets: [
        makeLibraryTarget(name: "ST826", dependencies: [])
    ]
)