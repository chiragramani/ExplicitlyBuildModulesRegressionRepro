import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST243",
    targets: [
        makeLibraryTarget(name: "ST243", dependencies: ["ST38", "ST44", "ST74", "ST92", "ST26", "ST96", "ST4", "ST161", "ST37"])
    ]
)