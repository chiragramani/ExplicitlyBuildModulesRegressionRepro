import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST144",
    targets: [
        makeLibraryTarget(name: "ST144", dependencies: ["ST143", "ST131", "ST23", "ST558", "ST27", "ST140", "ST96", "ST178", "ST92", "ST74", "ST38", "ST836", "ST62", "ST4", "ST26", "ST138", "ST176", "ST495", "ST515", "ST177", "ST179"])
    ]
)