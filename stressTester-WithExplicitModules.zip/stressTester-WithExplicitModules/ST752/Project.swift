import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST752",
    targets: [
        makeLibraryTarget(name: "ST752", dependencies: ["ST87", "ST92", "ST23", "ST102", "ST89", "ST754", "ST70", "ST20"])
    ]
)