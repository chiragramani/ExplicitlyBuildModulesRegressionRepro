import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST288",
    targets: [
        makeLibraryTarget(name: "ST288", dependencies: ["ST345", "ST131", "ST20", "ST421", "ST74", "ST96", "ST4", "ST138", "ST92", "ST37"])
    ]
)