import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST550",
    targets: [
        makeLibraryTarget(name: "ST550", dependencies: ["ST513", "ST102", "ST87", "ST746", "ST96", "ST20", "ST70", "ST74", "ST178", "ST26", "ST92", "ST89"])
    ]
)