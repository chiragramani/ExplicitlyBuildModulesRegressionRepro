import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST979",
    targets: [
        makeLibraryTarget(name: "ST979", dependencies: ["ST38", "ST44"])
    ]
)