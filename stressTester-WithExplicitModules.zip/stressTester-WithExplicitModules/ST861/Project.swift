import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST861",
    targets: [
        makeLibraryTarget(name: "ST861", dependencies: ["ST531", "ST92", "ST96", "ST26", "ST530", "ST89", "ST87", "ST70", "ST20", "ST4", "ST54", "ST586", "ST14", "ST102", "ST74"])
    ]
)