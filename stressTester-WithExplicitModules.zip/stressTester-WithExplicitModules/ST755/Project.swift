import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST755",
    targets: [
        makeLibraryTarget(name: "ST755", dependencies: ["ST507"])
    ]
)