import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST338",
    targets: [
        makeLibraryTarget(name: "ST338", dependencies: ["ST102", "ST20", "ST223", "ST540", "ST74", "ST62", "ST4", "ST26", "ST250", "ST261", "ST187", "ST87", "ST249", "ST23", "ST313", "ST321", "ST403", "ST342", "ST270", "ST70", "ST131", "ST391", "ST214", "ST89", "ST140", "ST90", "ST38", "ST72", "ST142", "ST314", "ST96", "ST68", "ST52", "ST336", "ST367", "ST349", "ST390", "ST538", "ST590", "ST657", "ST213", "ST267", "ST11", "ST27", "ST227", "ST293", "ST290", "ST92", "ST31", "ST41", "ST150", "ST54", "ST602", "ST138", "ST217", "ST192"])
    ]
)