import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST821",
    targets: [
        makeLibraryTarget(name: "ST821", dependencies: ["ST26"])
    ]
)