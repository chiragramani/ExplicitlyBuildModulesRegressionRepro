import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST955",
    targets: [
        makeLibraryTarget(name: "ST955", dependencies: ["ST44", "ST38"])
    ]
)