import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST172",
    targets: [
        makeLibraryTarget(name: "ST172", dependencies: ["ST92", "ST74", "ST96", "ST4", "ST26"])
    ]
)