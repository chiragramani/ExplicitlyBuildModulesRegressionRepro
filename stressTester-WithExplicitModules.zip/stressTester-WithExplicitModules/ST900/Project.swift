import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST900",
    targets: [
        makeLibraryTarget(name: "ST900", dependencies: ["ST38", "ST44"])
    ]
)