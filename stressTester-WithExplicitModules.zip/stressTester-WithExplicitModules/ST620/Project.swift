import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST620",
    targets: [
        makeLibraryTarget(name: "ST620", dependencies: ["ST1151", "ST89", "ST20", "ST74", "ST102", "ST4", "ST26", "ST38", "ST530", "ST88", "ST196", "ST599", "ST96", "ST70", "ST44", "ST92", "ST531"])
    ]
)