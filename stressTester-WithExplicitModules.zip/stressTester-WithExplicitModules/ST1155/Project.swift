import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1155",
    targets: [
        makeLibraryTarget(name: "ST1155", dependencies: ["ST1157", "ST1141", "ST1158", "ST1159", "ST1156", "ST507"])
    ]
)