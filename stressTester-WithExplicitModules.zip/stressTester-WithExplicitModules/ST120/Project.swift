import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST120",
    targets: [
        makeLibraryTarget(name: "ST120", dependencies: ["ST92", "ST136"])
    ]
)