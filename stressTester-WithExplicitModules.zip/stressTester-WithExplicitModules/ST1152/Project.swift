import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1152",
    targets: [
        makeLibraryTarget(name: "ST1152", dependencies: [])
    ]
)