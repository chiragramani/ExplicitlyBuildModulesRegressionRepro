import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST413",
    targets: [
        makeLibraryTarget(name: "ST413", dependencies: ["ST379", "ST452", "ST187", "ST23", "ST26", "ST138", "ST74", "ST425", "ST4", "ST416", "ST96", "ST92"])
    ]
)