import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1004",
    targets: [
        makeLibraryTarget(name: "ST1004", dependencies: ["ST38", "ST44"])
    ]
)