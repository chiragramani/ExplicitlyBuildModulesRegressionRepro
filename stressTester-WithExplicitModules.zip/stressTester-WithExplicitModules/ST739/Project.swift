import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST739",
    targets: [
        makeLibraryTarget(name: "ST739", dependencies: ["ST434", "ST96", "ST92", "ST89", "ST196", "ST26", "ST74", "ST54", "ST102", "ST20", "ST427", "ST70", "ST4", "ST529", "ST195", "ST822", "ST742"])
    ]
)