import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST102",
    targets: [
        makeLibraryTarget(name: "ST102", dependencies: ["ST552", "ST192", "ST4", "ST70", "ST89", "ST20", "ST186", "ST44", "ST26", "ST196", "ST96", "ST87", "ST65", "ST187", "ST74", "ST92", "ST88", "ST38", "ST199"])
    ]
)