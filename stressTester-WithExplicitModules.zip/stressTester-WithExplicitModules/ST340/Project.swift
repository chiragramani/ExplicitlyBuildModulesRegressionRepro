import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST340",
    targets: [
        makeLibraryTarget(name: "ST340", dependencies: ["ST449", "ST90", "ST74", "ST431", "ST70", "ST20", "ST136", "ST509", "ST342", "ST327", "ST348", "ST217", "ST146", "ST44", "ST511", "ST161", "ST155", "ST102", "ST137", "ST23", "ST75", "ST588", "ST27", "ST45", "ST213", "ST187", "ST4", "ST11", "ST589", "ST81", "ST569", "ST38", "ST323", "ST287", "ST178", "ST223", "ST391", "ST48", "ST26", "ST89", "ST96", "ST321", "ST138", "ST142", "ST150", "ST32", "ST131", "ST192", "ST513", "ST87", "ST54", "ST157", "ST309", "ST139", "ST92", "ST336", "ST62", "ST145", "ST176", "ST390", "ST37"])
    ]
)