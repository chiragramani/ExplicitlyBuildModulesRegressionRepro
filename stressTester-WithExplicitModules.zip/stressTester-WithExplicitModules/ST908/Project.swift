import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST908",
    targets: [
        makeLibraryTarget(name: "ST908", dependencies: ["ST507", "ST560", "ST38", "ST94"])
    ]
)