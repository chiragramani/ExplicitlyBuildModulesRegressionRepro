import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST158",
    targets: [
        makeLibraryTarget(name: "ST158", dependencies: ["ST186", "ST96", "ST4", "ST37", "ST44", "ST26", "ST38", "ST92"])
    ]
)