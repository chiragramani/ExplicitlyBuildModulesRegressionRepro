import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST220",
    targets: [
        makeLibraryTarget(name: "ST220", dependencies: ["ST590", "ST4", "ST38", "ST92", "ST89", "ST214", "ST37", "ST26", "ST74", "ST102", "ST591", "ST195", "ST44"])
    ]
)