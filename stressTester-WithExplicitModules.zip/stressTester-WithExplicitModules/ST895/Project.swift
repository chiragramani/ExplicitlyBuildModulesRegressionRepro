import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST895",
    targets: [
        makeLibraryTarget(name: "ST895", dependencies: ["ST44", "ST38"])
    ]
)