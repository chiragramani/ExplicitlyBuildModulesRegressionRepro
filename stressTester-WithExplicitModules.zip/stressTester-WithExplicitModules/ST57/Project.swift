import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST57",
    targets: [
        makeLibraryTarget(name: "ST57", dependencies: ["ST803", "ST95", "ST179", "ST83", "ST625", "ST196", "ST804", "ST74", "ST92", "ST55", "ST69", "ST8", "ST178", "ST90", "ST154", "ST205", "ST94", "ST37", "ST22", "ST4", "ST73", "ST429", "ST26", "ST28", "ST54", "ST49", "ST38", "ST170", "ST805", "ST99", "ST24", "ST165", "ST502", "ST422", "ST167", "ST806", "ST101", "ST807", "ST519", "ST171", "ST23", "ST161", "ST197", "ST13", "ST65", "ST100", "ST29", "ST71", "ST93", "ST529", "ST430", "ST80", "ST77", "ST187", "ST61", "ST168", "ST96", "ST20", "ST82", "ST765", "ST79"])
    ]
)