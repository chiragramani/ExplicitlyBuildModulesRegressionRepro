import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1148",
    targets: [
        makeLibraryTarget(name: "ST1148", dependencies: ["ST4", "ST80", "ST27", "ST38", "ST26", "ST44"])
    ]
)