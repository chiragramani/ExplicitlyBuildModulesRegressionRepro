import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST906",
    targets: [
        makeLibraryTarget(name: "ST906", dependencies: ["ST507"])
    ]
)