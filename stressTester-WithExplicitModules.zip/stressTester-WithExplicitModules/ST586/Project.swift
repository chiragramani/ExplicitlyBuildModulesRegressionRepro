import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST586",
    targets: [
        makeLibraryTarget(name: "ST586", dependencies: ["ST80", "ST26", "ST4", "ST44", "ST38", "ST601"])
    ]
)