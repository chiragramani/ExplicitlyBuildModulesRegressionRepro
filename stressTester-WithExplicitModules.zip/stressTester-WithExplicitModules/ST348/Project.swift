import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST348",
    targets: [
        makeLibraryTarget(name: "ST348", dependencies: ["ST102", "ST96", "ST58", "ST413", "ST26", "ST81", "ST89", "ST391", "ST44", "ST4", "ST49", "ST195", "ST716", "ST27", "ST379", "ST90", "ST530", "ST376", "ST70", "ST62", "ST150", "ST37", "ST72", "ST531", "ST334", "ST517", "ST315", "ST416", "ST23", "ST38", "ST192", "ST635", "ST20", "ST551", "ST717", "ST80", "ST54", "ST172", "ST92", "ST24", "ST131", "ST74", "ST349", "ST161", "ST138"])
    ]
)