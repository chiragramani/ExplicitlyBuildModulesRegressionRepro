import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST11",
    targets: [
        makeLibraryTarget(name: "ST11", dependencies: ["ST249", "ST37", "ST225", "ST439", "ST102", "ST450", "ST223", "ST20", "ST44", "ST54", "ST26", "ST593", "ST491", "ST68", "ST214", "ST70", "ST74", "ST187", "ST96", "ST4", "ST468", "ST524", "ST92"])
    ]
)