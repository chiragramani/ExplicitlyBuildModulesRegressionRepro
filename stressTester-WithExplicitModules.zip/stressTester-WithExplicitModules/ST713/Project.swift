import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST713",
    targets: [
        makeLibraryTarget(name: "ST713", dependencies: ["ST192", "ST26", "ST80", "ST189", "ST4", "ST596", "ST38", "ST44"])
    ]
)