import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST953",
    targets: [
        makeLibraryTarget(name: "ST953", dependencies: ["ST38", "ST44"])
    ]
)