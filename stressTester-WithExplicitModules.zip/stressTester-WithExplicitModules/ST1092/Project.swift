import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1092",
    targets: [
        makeLibraryTarget(name: "ST1092", dependencies: ["ST44", "ST38"])
    ]
)