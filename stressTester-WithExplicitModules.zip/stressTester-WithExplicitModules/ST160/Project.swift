import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST160",
    targets: [
        makeLibraryTarget(name: "ST160", dependencies: ["ST4", "ST96", "ST161", "ST65", "ST37", "ST92", "ST44", "ST38", "ST74", "ST26"])
    ]
)