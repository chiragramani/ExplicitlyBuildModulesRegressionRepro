import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST56",
    targets: [
        makeLibraryTarget(name: "ST56", dependencies: ["ST44", "ST89", "ST20", "ST74", "ST96", "ST70", "ST92", "ST102", "ST26", "ST534", "ST45"])
    ]
)