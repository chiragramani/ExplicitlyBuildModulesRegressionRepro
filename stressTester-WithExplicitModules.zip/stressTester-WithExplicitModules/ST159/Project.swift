import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST159",
    targets: [
        makeLibraryTarget(name: "ST159", dependencies: ["ST566", "ST44", "ST38", "ST20", "ST24", "ST96", "ST26", "ST637", "ST92", "ST74", "ST100"])
    ]
)