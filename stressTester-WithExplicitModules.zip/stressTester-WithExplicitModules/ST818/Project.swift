import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST818",
    targets: [
        makeLibraryTarget(name: "ST818", dependencies: [])
    ]
)