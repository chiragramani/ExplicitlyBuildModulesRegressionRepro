import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST423",
    targets: [
        makeLibraryTarget(name: "ST423", dependencies: ["ST26", "ST74", "ST187", "ST37", "ST92", "ST432", "ST161", "ST153", "ST96", "ST4"])
    ]
)