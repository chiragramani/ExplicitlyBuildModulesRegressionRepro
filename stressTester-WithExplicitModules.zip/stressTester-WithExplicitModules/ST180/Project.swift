import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST180",
    targets: [
        makeLibraryTarget(name: "ST180", dependencies: ["ST196", "ST92", "ST71", "ST96", "ST187", "ST4", "ST37", "ST433", "ST26", "ST20", "ST74", "ST38", "ST102", "ST598", "ST61", "ST86", "ST87", "ST195", "ST44", "ST644", "ST89", "ST161", "ST80", "ST70", "ST65"])
    ]
)