import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST391",
    targets: [
        makeLibraryTarget(name: "ST391", dependencies: ["ST70", "ST196", "ST75", "ST27", "ST140", "ST102", "ST4", "ST26", "ST131", "ST32", "ST90", "ST89", "ST602", "ST145", "ST142", "ST74", "ST588", "ST38", "ST139", "ST195", "ST23", "ST37", "ST65", "ST157", "ST192", "ST150", "ST87", "ST44", "ST48", "ST431", "ST187", "ST96", "ST81", "ST20", "ST138", "ST92"])
    ]
)