import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST370",
    targets: [
        makeLibraryTarget(name: "ST370", dependencies: ["ST64", "ST96", "ST38", "ST92", "ST230", "ST26", "ST85", "ST131", "ST29", "ST33"])
    ]
)