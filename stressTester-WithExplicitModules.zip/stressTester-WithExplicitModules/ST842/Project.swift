import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST842",
    targets: [
        makeLibraryTarget(name: "ST842", dependencies: ["ST843", "ST102", "ST26", "ST147", "ST844", "ST845", "ST20"])
    ]
)