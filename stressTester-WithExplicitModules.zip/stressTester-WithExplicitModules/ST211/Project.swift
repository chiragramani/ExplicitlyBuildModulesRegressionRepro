import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST211",
    targets: [
        makeLibraryTarget(name: "ST211", dependencies: ["ST250", "ST469", "ST20", "ST663", "ST273", "ST70", "ST468", "ST102", "ST92", "ST68", "ST26", "ST214", "ST89", "ST470", "ST96", "ST74"])
    ]
)