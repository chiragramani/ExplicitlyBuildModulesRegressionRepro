import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST544",
    targets: [
        makeLibraryTarget(name: "ST544", dependencies: ["ST96", "ST336", "ST92", "ST131", "ST154", "ST62", "ST178", "ST150", "ST20", "ST138", "ST38", "ST74", "ST49", "ST376", "ST513", "ST26", "ST89", "ST425", "ST23", "ST90", "ST271", "ST452", "ST140", "ST290", "ST549"])
    ]
)