import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST221",
    targets: [
        makeLibraryTarget(name: "ST221", dependencies: ["ST220", "ST4", "ST38", "ST591", "ST195", "ST26", "ST593", "ST74", "ST92", "ST187", "ST11", "ST214", "ST223"])
    ]
)