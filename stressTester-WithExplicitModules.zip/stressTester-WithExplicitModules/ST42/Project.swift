import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST42",
    targets: [
        makeLibraryTarget(name: "ST42", dependencies: ["ST92", "ST202", "ST186", "ST26", "ST93", "ST4", "ST77", "ST94", "ST96", "ST44", "ST74", "ST38", "ST203"])
    ]
)