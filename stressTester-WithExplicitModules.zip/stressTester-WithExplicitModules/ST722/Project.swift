import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST722",
    targets: [
        makeLibraryTarget(name: "ST722", dependencies: ["ST26"])
    ]
)