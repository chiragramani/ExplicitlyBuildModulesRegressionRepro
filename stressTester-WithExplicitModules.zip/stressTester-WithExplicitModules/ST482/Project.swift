import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST482",
    targets: [
        makeLibraryTarget(name: "ST482", dependencies: ["ST19", "ST74", "ST100", "ST96", "ST637", "ST92", "ST37", "ST61", "ST161", "ST483", "ST429", "ST54", "ST484", "ST44", "ST20", "ST23", "ST26", "ST89", "ST733", "ST430", "ST99", "ST70", "ST71", "ST102", "ST38", "ST566", "ST60", "ST4"])
    ]
)