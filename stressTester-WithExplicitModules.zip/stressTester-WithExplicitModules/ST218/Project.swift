import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST218",
    targets: [
        makeLibraryTarget(name: "ST218", dependencies: ["ST70", "ST38", "ST96", "ST89", "ST92", "ST26", "ST71", "ST151", "ST20", "ST102", "ST61", "ST74"])
    ]
)