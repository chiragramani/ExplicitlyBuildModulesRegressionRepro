import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST930",
    targets: [
        makeLibraryTarget(name: "ST930", dependencies: ["ST38", "ST44"])
    ]
)