import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST89",
    targets: [
        makeLibraryTarget(name: "ST89", dependencies: [])
    ]
)