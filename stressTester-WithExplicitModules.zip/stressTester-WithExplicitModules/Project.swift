import ProjectDescription

let project = Project(
    name: "StressTesterApp",
    targets: [
        .target(
            name: "StressTesterApp",
            destinations: .iOS,
            product: .app,
            bundleId: "com.uber.dev.stress.tester.app",
            sources: ["ST0/Sources/**"],
            dependencies: [
                .project(target: "ST1", path: "ST1"),
.project(target: "ST2", path: "ST2"),
.project(target: "ST3", path: "ST3"),
.project(target: "ST4", path: "ST4"),
.project(target: "ST5", path: "ST5")
            ]
        )
    ]
)
