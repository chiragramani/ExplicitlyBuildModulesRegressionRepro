import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST616",
    targets: [
        makeLibraryTarget(name: "ST616", dependencies: ["ST161", "ST29", "ST68", "ST23", "ST96", "ST26", "ST4", "ST92", "ST37"])
    ]
)