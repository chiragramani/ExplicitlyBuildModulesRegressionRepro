import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST568",
    targets: [
        makeLibraryTarget(name: "ST568", dependencies: ["ST74", "ST138", "ST150", "ST347", "ST137", "ST26", "ST131", "ST92", "ST96"])
    ]
)