import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST274",
    targets: [
        makeLibraryTarget(name: "ST274", dependencies: ["ST20", "ST584", "ST71", "ST161", "ST29", "ST26", "ST102", "ST187", "ST50", "ST531", "ST532", "ST74", "ST192", "ST196", "ST530", "ST44", "ST38", "ST87", "ST88", "ST4", "ST61", "ST257", "ST37", "ST92", "ST70", "ST89", "ST96"])
    ]
)