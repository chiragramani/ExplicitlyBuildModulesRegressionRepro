import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST19",
    targets: [
        makeLibraryTarget(name: "ST19", dependencies: ["ST102", "ST88", "ST70", "ST192", "ST38", "ST96", "ST71", "ST92", "ST8", "ST69", "ST89", "ST44", "ST74", "ST87", "ST26", "ST61", "ST23", "ST4", "ST163", "ST20"])
    ]
)