import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST341",
    targets: [
        makeLibraryTarget(name: "ST341", dependencies: ["ST11", "ST70", "ST32", "ST131", "ST136", "ST148", "ST551", "ST139", "ST223", "ST150", "ST162", "ST26", "ST27", "ST75", "ST138", "ST23", "ST417", "ST195", "ST90", "ST89", "ST30", "ST92", "ST137", "ST147", "ST102", "ST74", "ST509", "ST20", "ST96", "ST62", "ST49", "ST140", "ST376", "ST214"])
    ]
)