import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST701",
    targets: [
        makeLibraryTarget(name: "ST701", dependencies: ["ST44", "ST596", "ST189", "ST38"])
    ]
)