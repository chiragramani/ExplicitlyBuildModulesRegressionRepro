import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST242",
    targets: [
        makeLibraryTarget(name: "ST242", dependencies: ["ST263", "ST186", "ST87", "ST667", "ST68", "ST799", "ST264", "ST690", "ST611", "ST713", "ST846", "ST514", "ST798", "ST102", "ST489", "ST174", "ST38", "ST92", "ST847", "ST90", "ST253", "ST192", "ST214", "ST96", "ST173", "ST89", "ST796", "ST20", "ST26", "ST80", "ST162", "ST657", "ST244", "ST70", "ST531", "ST530", "ST267", "ST84", "ST25", "ST673", "ST692", "ST278", "ST18", "ST587", "ST666", "ST4", "ST74", "ST524"])
    ]
)