import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST558",
    targets: [
        makeLibraryTarget(name: "ST558", dependencies: ["ST179", "ST96", "ST23", "ST176", "ST513", "ST178", "ST26"])
    ]
)