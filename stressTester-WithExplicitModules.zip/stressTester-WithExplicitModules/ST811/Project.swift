import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST811",
    targets: [
        makeLibraryTarget(name: "ST811", dependencies: [])
    ]
)