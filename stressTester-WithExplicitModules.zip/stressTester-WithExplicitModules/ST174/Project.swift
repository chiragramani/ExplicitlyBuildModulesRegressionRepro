import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST174",
    targets: [
        makeLibraryTarget(name: "ST174", dependencies: ["ST203", "ST4", "ST173", "ST532", "ST96", "ST74", "ST880", "ST92", "ST1152", "ST1153", "ST89", "ST26", "ST44", "ST37", "ST95", "ST38"])
    ]
)