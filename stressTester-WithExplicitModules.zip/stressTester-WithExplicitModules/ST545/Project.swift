import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST545",
    targets: [
        makeLibraryTarget(name: "ST545", dependencies: ["ST336", "ST138", "ST404", "ST150", "ST392", "ST74", "ST161", "ST190", "ST92", "ST89", "ST131", "ST26", "ST37"])
    ]
)