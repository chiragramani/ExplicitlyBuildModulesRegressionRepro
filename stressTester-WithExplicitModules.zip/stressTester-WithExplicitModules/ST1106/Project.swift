import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1106",
    targets: [
        makeLibraryTarget(name: "ST1106", dependencies: ["ST44", "ST38"])
    ]
)