import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST963",
    targets: [
        makeLibraryTarget(name: "ST963", dependencies: ["ST38", "ST44"])
    ]
)