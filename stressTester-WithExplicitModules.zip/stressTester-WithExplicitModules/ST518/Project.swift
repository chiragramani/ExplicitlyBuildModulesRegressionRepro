import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST518",
    targets: [
        makeLibraryTarget(name: "ST518", dependencies: ["ST70", "ST92", "ST26", "ST23", "ST102", "ST96", "ST20", "ST89", "ST74", "ST515", "ST87"])
    ]
)