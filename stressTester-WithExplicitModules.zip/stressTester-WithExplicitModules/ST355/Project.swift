import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST355",
    targets: [
        makeLibraryTarget(name: "ST355", dependencies: ["ST20", "ST26", "ST429", "ST102", "ST96", "ST4", "ST430", "ST92", "ST142", "ST89", "ST496", "ST99"])
    ]
)