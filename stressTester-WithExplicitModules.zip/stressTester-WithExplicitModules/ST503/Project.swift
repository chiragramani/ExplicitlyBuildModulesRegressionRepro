import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST503",
    targets: [
        makeLibraryTarget(name: "ST503", dependencies: ["ST38", "ST74", "ST92", "ST26", "ST93", "ST96", "ST44"])
    ]
)