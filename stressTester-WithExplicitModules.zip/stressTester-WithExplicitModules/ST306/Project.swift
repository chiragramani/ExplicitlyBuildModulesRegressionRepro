import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST306",
    targets: [
        makeLibraryTarget(name: "ST306", dependencies: ["ST307", "ST26", "ST92", "ST142", "ST141", "ST54", "ST147", "ST70", "ST89", "ST135", "ST145", "ST138", "ST140", "ST27", "ST23", "ST4", "ST12", "ST38", "ST146", "ST96", "ST427", "ST102", "ST74", "ST131", "ST150", "ST139", "ST531", "ST323", "ST20", "ST87", "ST176"])
    ]
)