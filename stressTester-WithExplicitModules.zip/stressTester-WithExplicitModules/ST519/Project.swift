import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST519",
    targets: [
        makeLibraryTarget(name: "ST519", dependencies: ["ST583", "ST93", "ST806", "ST28", "ST803", "ST74", "ST96", "ST1168", "ST44", "ST807", "ST38", "ST4", "ST529"])
    ]
)