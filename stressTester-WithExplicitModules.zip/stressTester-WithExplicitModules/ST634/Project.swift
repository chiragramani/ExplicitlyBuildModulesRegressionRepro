import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST634",
    targets: [
        makeLibraryTarget(name: "ST634", dependencies: ["ST38", "ST94", "ST507"])
    ]
)