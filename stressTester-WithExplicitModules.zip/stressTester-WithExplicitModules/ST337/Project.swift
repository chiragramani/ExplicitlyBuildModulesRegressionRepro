import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST337",
    targets: [
        makeLibraryTarget(name: "ST337", dependencies: ["ST96", "ST74", "ST20", "ST4", "ST131", "ST44", "ST70", "ST138", "ST38", "ST92", "ST26", "ST89", "ST102"])
    ]
)