import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST511",
    targets: [
        makeLibraryTarget(name: "ST511", dependencies: ["ST20", "ST138", "ST26", "ST145", "ST150", "ST102", "ST139", "ST4", "ST136", "ST391", "ST89", "ST70", "ST131", "ST58", "ST92", "ST140", "ST11", "ST87", "ST509", "ST74"])
    ]
)