import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST192",
    targets: [
        makeLibraryTarget(name: "ST192", dependencies: ["ST507", "ST838", "ST96", "ST44", "ST536", "ST26", "ST4", "ST48", "ST74", "ST501", "ST531", "ST709", "ST38", "ST20"])
    ]
)