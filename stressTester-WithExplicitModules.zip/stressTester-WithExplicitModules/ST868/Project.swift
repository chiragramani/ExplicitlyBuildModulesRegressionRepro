import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST868",
    targets: [
        makeLibraryTarget(name: "ST868", dependencies: ["ST102", "ST44", "ST192", "ST96", "ST87", "ST20", "ST92", "ST38"])
    ]
)