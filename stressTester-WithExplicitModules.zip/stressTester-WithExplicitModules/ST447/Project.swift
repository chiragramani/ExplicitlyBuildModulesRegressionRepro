import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST447",
    targets: [
        makeLibraryTarget(name: "ST447", dependencies: ["ST38", "ST99", "ST100", "ST102", "ST92", "ST74", "ST20", "ST4", "ST530", "ST24", "ST80", "ST70", "ST429", "ST81", "ST596", "ST89", "ST37", "ST430", "ST87", "ST427", "ST505", "ST61", "ST44", "ST96", "ST26", "ST445", "ST531", "ST535"])
    ]
)