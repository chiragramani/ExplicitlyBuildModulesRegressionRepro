import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST790",
    targets: [
        makeLibraryTarget(name: "ST790", dependencies: ["ST278", "ST74", "ST96", "ST26", "ST253", "ST214", "ST20", "ST92", "ST524", "ST68", "ST89"])
    ]
)