import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST483",
    targets: [
        makeLibraryTarget(name: "ST483", dependencies: ["ST89", "ST96", "ST430", "ST195", "ST192", "ST61", "ST484", "ST44", "ST187", "ST99", "ST429", "ST20", "ST87", "ST733", "ST74", "ST736", "ST54", "ST38", "ST196", "ST26", "ST60", "ST71", "ST92", "ST102", "ST70", "ST95", "ST4", "ST23"])
    ]
)