import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST976",
    targets: [
        makeLibraryTarget(name: "ST976", dependencies: ["ST44", "ST38"])
    ]
)