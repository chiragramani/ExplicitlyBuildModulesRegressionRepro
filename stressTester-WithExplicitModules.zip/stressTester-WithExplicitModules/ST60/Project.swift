import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST60",
    targets: [
        makeLibraryTarget(name: "ST60", dependencies: ["ST4", "ST20", "ST102", "ST38", "ST54", "ST26", "ST70", "ST196", "ST74", "ST484", "ST192", "ST163", "ST96", "ST87", "ST92", "ST44"])
    ]
)