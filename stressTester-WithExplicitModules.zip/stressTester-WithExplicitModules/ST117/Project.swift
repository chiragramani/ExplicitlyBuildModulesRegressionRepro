import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST117",
    targets: [
        makeLibraryTarget(name: "ST117", dependencies: ["ST178", "ST58", "ST556", "ST126", "ST557", "ST192", "ST146", "ST83", "ST139", "ST23", "ST558", "ST102", "ST512", "ST89", "ST145", "ST26", "ST131", "ST92", "ST70", "ST20", "ST38", "ST140", "ST96", "ST4", "ST137", "ST32", "ST53", "ST7", "ST27", "ST195", "ST75", "ST74", "ST176", "ST54", "ST179", "ST162", "ST138", "ST194"])
    ]
)