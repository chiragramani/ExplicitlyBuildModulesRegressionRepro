import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST437",
    targets: [
        makeLibraryTarget(name: "ST437", dependencies: ["ST23", "ST879", "ST26", "ST92", "ST38"])
    ]
)