import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1139",
    targets: [
        makeLibraryTarget(name: "ST1139", dependencies: ["ST44", "ST38"])
    ]
)