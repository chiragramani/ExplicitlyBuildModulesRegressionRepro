import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST10",
    targets: [
        makeLibraryTarget(name: "ST10", dependencies: ["ST99", "ST629", "ST81", "ST154", "ST555", "ST178", "ST44", "ST630", "ST628", "ST96", "ST631", "ST484", "ST51", "ST176", "ST161", "ST11", "ST16", "ST223", "ST56", "ST439", "ST40", "ST38", "ST159", "ST632", "ST633", "ST195", "ST61", "ST77", "ST257", "ST627", "ST529", "ST192", "ST89", "ST24", "ST60", "ST26", "ST54", "ST634", "ST422", "ST258", "ST74", "ST483", "ST156", "ST102", "ST45", "ST4", "ST23", "ST187", "ST196", "ST552", "ST37", "ST20", "ST625", "ST100", "ST63", "ST626", "ST70", "ST92"])
    ]
)