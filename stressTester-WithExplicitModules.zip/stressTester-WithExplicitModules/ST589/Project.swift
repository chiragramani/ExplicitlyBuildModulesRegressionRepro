import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST589",
    targets: [
        makeLibraryTarget(name: "ST589", dependencies: ["ST96", "ST439", "ST89", "ST4", "ST74", "ST102", "ST92", "ST26", "ST20", "ST87"])
    ]
)