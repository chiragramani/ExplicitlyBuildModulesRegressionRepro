import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST673",
    targets: [
        makeLibraryTarget(name: "ST673", dependencies: ["ST92", "ST214", "ST89", "ST690"])
    ]
)