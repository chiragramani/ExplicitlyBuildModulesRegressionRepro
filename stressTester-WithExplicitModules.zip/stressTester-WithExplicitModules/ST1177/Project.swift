import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1177",
    targets: [
        makeLibraryTarget(name: "ST1177", dependencies: [])
    ]
)