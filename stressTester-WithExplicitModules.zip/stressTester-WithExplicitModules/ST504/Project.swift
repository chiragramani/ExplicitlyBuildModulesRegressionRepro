import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST504",
    targets: [
        makeLibraryTarget(name: "ST504", dependencies: ["ST74", "ST88", "ST92", "ST87", "ST26", "ST102", "ST195", "ST70", "ST37", "ST173", "ST174", "ST96", "ST89", "ST4", "ST20", "ST620"])
    ]
)