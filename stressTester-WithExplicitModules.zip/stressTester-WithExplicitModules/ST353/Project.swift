import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST353",
    targets: [
        makeLibraryTarget(name: "ST353", dependencies: ["ST96", "ST241", "ST87", "ST23", "ST16", "ST38", "ST376", "ST26", "ST70", "ST74", "ST150", "ST20", "ST551", "ST89", "ST92", "ST138", "ST131", "ST530", "ST49", "ST436", "ST62", "ST258", "ST4", "ST179", "ST90", "ST178", "ST102", "ST447", "ST61", "ST531", "ST88", "ST37"])
    ]
)