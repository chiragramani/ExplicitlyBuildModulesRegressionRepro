import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST80",
    targets: [
        makeLibraryTarget(name: "ST80", dependencies: ["ST876", "ST875", "ST13", "ST835", "ST874", "ST529"])
    ]
)