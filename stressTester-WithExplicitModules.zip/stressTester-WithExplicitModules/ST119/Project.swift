import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST119",
    targets: [
        makeLibraryTarget(name: "ST119", dependencies: ["ST120", "ST37", "ST54", "ST102", "ST92", "ST136", "ST140", "ST74", "ST20", "ST148", "ST44", "ST38", "ST70", "ST138", "ST187", "ST26", "ST96", "ST89"])
    ]
)