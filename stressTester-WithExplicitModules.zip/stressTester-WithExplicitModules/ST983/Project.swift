import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST983",
    targets: [
        makeLibraryTarget(name: "ST983", dependencies: ["ST38", "ST44"])
    ]
)