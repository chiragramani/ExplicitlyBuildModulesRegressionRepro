import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST674",
    targets: [
        makeLibraryTarget(name: "ST674", dependencies: ["ST26", "ST92"])
    ]
)