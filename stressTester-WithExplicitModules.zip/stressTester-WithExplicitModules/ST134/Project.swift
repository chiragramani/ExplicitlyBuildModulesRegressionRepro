import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST134",
    targets: [
        makeLibraryTarget(name: "ST134", dependencies: ["ST166", "ST23", "ST197", "ST606", "ST608", "ST198", "ST21", "ST761", "ST96", "ST133"])
    ]
)