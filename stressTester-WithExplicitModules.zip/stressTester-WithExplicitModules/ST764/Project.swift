import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST764",
    targets: [
        makeLibraryTarget(name: "ST764", dependencies: [])
    ]
)