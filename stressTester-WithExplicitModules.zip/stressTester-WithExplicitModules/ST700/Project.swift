import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST700",
    targets: [
        makeLibraryTarget(name: "ST700", dependencies: ["ST674", "ST20", "ST92", "ST195", "ST89", "ST74", "ST90", "ST26", "ST38", "ST4", "ST102", "ST96", "ST667", "ST214", "ST68", "ST705"])
    ]
)