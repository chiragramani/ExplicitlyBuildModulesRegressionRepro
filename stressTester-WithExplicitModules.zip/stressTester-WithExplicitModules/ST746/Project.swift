import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST746",
    targets: [
        makeLibraryTarget(name: "ST746", dependencies: ["ST178", "ST513", "ST102", "ST23", "ST26", "ST187", "ST20"])
    ]
)