import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST985",
    targets: [
        makeLibraryTarget(name: "ST985", dependencies: ["ST38", "ST44"])
    ]
)