import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST941",
    targets: [
        makeLibraryTarget(name: "ST941", dependencies: ["ST38", "ST44"])
    ]
)