import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST390",
    targets: [
        makeLibraryTarget(name: "ST390", dependencies: ["ST38", "ST102", "ST89", "ST323", "ST26", "ST90", "ST309", "ST30", "ST11", "ST223", "ST195", "ST136", "ST588", "ST4", "ST213", "ST75", "ST139", "ST192", "ST551", "ST76", "ST214", "ST403", "ST417", "ST32", "ST140", "ST196", "ST74", "ST91", "ST67", "ST81", "ST96", "ST87", "ST391", "ST161", "ST150", "ST62", "ST186", "ST176", "ST142", "ST147", "ST27", "ST376", "ST37", "ST321", "ST45", "ST452", "ST138", "ST137", "ST20", "ST287", "ST70", "ST92", "ST148", "ST131"])
    ]
)