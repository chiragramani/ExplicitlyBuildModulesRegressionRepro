import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST827",
    targets: [
        makeLibraryTarget(name: "ST827", dependencies: ["ST829", "ST830", "ST826", "ST5"])
    ]
)