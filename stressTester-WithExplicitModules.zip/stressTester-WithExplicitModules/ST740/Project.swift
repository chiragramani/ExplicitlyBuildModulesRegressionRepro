import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST740",
    targets: [
        makeLibraryTarget(name: "ST740", dependencies: ["ST842", "ST20"])
    ]
)