import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST843",
    targets: [
        makeLibraryTarget(name: "ST843", dependencies: ["ST20"])
    ]
)