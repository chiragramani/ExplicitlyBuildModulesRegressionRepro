import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST587",
    targets: [
        makeLibraryTarget(name: "ST587", dependencies: ["ST18", "ST25", "ST690", "ST524", "ST26", "ST214", "ST92"])
    ]
)