#!/bin/bash


PROJECT_PATH="StressTesterApp.xcworkspace"
SCHEME="StressTesterApp"

# Base path for result bundles
RESULT_BUNDLE_BASE_PATH="./ResultBundles"

# Ensure the result bundles directory exists
rm -rf "$RESULT_BUNDLE_BASE_PATH"
mkdir -p "$RESULT_BUNDLE_BASE_PATH"

# Function to clean derived data
clean_derived_data() {
    echo "Cleaning Derived Data..."
    rm -rf ~/Library/Developer/Xcode/DerivedData
    if [ $? -ne 0 ]; then
        echo "Failed to clean Derived Data."
        exit 1
    else
        echo "Derived Data cleaned successfully."
    fi
}

build_project() {
    local build_number=$1
    local result_bundle_path="$RESULT_BUNDLE_BASE_PATH/Build_${build_number}.xcresult"

    echo "Building project - Attempt #$build_number"
    xcodebuild \
        -workspace "$PROJECT_PATH" \
        -scheme "$SCHEME" \
        -destination "platform=iOS Simulator,name=iPhone 16 Pro" \
        -resultBundlePath "$result_bundle_path" \
        clean build

    if [ $? -ne 0 ]; then
        echo "Build #$build_number failed. Check logs for details."
        exit 1
    else
        echo "Build #$build_number completed successfully. Result bundle: $result_bundle_path"
    fi
}


for i in {1..3}; do
    clean_derived_data
    build_project $i
done

echo "All builds completed successfully."
