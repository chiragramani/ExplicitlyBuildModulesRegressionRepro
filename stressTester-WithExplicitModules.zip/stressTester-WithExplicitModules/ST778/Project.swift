import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST778",
    targets: [
        makeLibraryTarget(name: "ST778", dependencies: ["ST531", "ST18", "ST214", "ST20", "ST70", "ST278", "ST253", "ST192", "ST692", "ST89", "ST74", "ST26", "ST96", "ST87", "ST524", "ST92", "ST65", "ST666", "ST587", "ST25", "ST690", "ST68", "ST665", "ST54", "ST242", "ST798", "ST530", "ST37", "ST38", "ST4", "ST102", "ST263"])
    ]
)