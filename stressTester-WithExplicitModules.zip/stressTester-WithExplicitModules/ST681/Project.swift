import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST681",
    targets: [
        makeLibraryTarget(name: "ST681", dependencies: ["ST695", "ST26", "ST38", "ST195", "ST92", "ST263", "ST214", "ST187", "ST68", "ST524", "ST74", "ST702", "ST96"])
    ]
)