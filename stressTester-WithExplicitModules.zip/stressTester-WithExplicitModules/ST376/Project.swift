import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST376",
    targets: [
        makeLibraryTarget(name: "ST376", dependencies: ["ST38", "ST96", "ST70", "ST62", "ST92", "ST37", "ST102", "ST495", "ST528", "ST194", "ST176", "ST138", "ST361", "ST543", "ST452", "ST513", "ST4", "ST551", "ST150", "ST20", "ST26", "ST748", "ST178", "ST425", "ST287", "ST187", "ST23", "ST88", "ST823", "ST149", "ST416", "ST379", "ST29", "ST90", "ST74", "ST192", "ST139", "ST131"])
    ]
)