import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1130",
    targets: [
        makeLibraryTarget(name: "ST1130", dependencies: ["ST38", "ST44"])
    ]
)