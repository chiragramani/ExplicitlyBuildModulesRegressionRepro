import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST816",
    targets: [
        makeLibraryTarget(name: "ST816", dependencies: ["ST817", "ST818"])
    ]
)