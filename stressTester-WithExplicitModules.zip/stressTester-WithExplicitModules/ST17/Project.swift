import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST17",
    targets: [
        makeLibraryTarget(name: "ST17", dependencies: ["ST26", "ST38", "ST195", "ST96", "ST704", "ST20", "ST89", "ST68", "ST92", "ST102", "ST192", "ST468", "ST225", "ST70"])
    ]
)