import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST440",
    targets: [
        makeLibraryTarget(name: "ST440", dependencies: ["ST20", "ST4", "ST192", "ST37", "ST89", "ST96", "ST44", "ST38", "ST74", "ST187", "ST80", "ST92", "ST87", "ST26", "ST102", "ST70"])
    ]
)