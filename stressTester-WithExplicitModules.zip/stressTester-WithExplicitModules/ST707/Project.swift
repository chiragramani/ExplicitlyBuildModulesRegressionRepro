import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST707",
    targets: [
        makeLibraryTarget(name: "ST707", dependencies: ["ST44", "ST596", "ST4", "ST26", "ST80", "ST38"])
    ]
)