import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST175",
    targets: [
        makeLibraryTarget(name: "ST175", dependencies: ["ST92", "ST887", "ST74", "ST4", "ST748", "ST96", "ST80", "ST201", "ST26", "ST44", "ST38"])
    ]
)