import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1067",
    targets: [
        makeLibraryTarget(name: "ST1067", dependencies: ["ST44", "ST38"])
    ]
)