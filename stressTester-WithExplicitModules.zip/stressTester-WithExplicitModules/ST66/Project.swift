import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST66",
    targets: [
        makeLibraryTarget(name: "ST66", dependencies: ["ST4", "ST94", "ST26", "ST38", "ST507", "ST96", "ST187"])
    ]
)