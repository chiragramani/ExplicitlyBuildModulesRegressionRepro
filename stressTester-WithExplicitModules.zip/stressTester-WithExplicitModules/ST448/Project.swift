import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST448",
    targets: [
        makeLibraryTarget(name: "ST448", dependencies: ["ST92", "ST532", "ST26", "ST531", "ST74", "ST44", "ST38", "ST48", "ST102", "ST96", "ST530", "ST183", "ST70", "ST4", "ST20", "ST210", "ST87", "ST529", "ST80", "ST89"])
    ]
)