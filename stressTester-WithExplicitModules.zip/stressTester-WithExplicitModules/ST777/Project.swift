import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST777",
    targets: [
        makeLibraryTarget(name: "ST777", dependencies: ["ST186", "ST92", "ST20", "ST652", "ST68", "ST87", "ST102", "ST796", "ST587", "ST242", "ST18", "ST26", "ST253", "ST192", "ST666", "ST690", "ST89", "ST673", "ST4", "ST214", "ST523", "ST96", "ST74", "ST23", "ST611", "ST25", "ST278", "ST524", "ST799", "ST70"])
    ]
)