import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST535",
    targets: [
        makeLibraryTarget(name: "ST535", dependencies: ["ST38", "ST192", "ST536", "ST709", "ST205", "ST44", "ST507"])
    ]
)