import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST81",
    targets: [
        makeLibraryTarget(name: "ST81", dependencies: ["ST96", "ST90", "ST195", "ST92", "ST192", "ST74", "ST596", "ST24", "ST26", "ST70", "ST189", "ST20", "ST89", "ST4", "ST535"])
    ]
)