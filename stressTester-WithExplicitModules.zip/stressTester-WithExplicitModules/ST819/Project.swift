import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST819",
    targets: [
        makeLibraryTarget(name: "ST819", dependencies: ["ST535", "ST44", "ST88", "ST96", "ST24", "ST102", "ST20", "ST507", "ST38", "ST26", "ST70"])
    ]
)