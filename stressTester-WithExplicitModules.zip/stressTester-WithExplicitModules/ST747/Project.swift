import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST747",
    targets: [
        makeLibraryTarget(name: "ST747", dependencies: ["ST748", "ST93", "ST48", "ST74", "ST749"])
    ]
)