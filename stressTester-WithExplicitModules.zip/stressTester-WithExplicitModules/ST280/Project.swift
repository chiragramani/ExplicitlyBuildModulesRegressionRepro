import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST280",
    targets: [
        makeLibraryTarget(name: "ST280", dependencies: ["ST38", "ST530", "ST89", "ST70", "ST11", "ST80", "ST20", "ST531", "ST96", "ST26", "ST223", "ST74", "ST92", "ST4", "ST213", "ST44", "ST102"])
    ]
)