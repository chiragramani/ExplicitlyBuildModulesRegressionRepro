import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST688",
    targets: [
        makeLibraryTarget(name: "ST688", dependencies: ["ST699", "ST26", "ST195", "ST38", "ST92", "ST667", "ST68", "ST704", "ST96", "ST89", "ST214", "ST74", "ST90"])
    ]
)