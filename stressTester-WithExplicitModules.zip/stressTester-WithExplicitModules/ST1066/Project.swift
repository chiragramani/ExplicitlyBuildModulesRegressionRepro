import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1066",
    targets: [
        makeLibraryTarget(name: "ST1066", dependencies: ["ST38", "ST44"])
    ]
)