import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST133",
    targets: [
        makeLibraryTarget(name: "ST133", dependencies: ["ST606", "ST9", "ST21", "ST166"])
    ]
)