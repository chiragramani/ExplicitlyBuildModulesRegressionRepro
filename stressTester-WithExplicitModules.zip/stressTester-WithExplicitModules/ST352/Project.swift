import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST352",
    targets: [
        makeLibraryTarget(name: "ST352", dependencies: ["ST26", "ST139", "ST364", "ST102", "ST23", "ST88", "ST403", "ST131", "ST37", "ST92", "ST4", "ST148", "ST54", "ST138", "ST243", "ST38", "ST257", "ST27", "ST89", "ST551", "ST178", "ST452", "ST44", "ST376", "ST513", "ST324", "ST390", "ST74", "ST191", "ST192", "ST96", "ST20", "ST62", "ST150", "ST299", "ST49", "ST90", "ST391", "ST70"])
    ]
)