import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST210",
    targets: [
        makeLibraryTarget(name: "ST210", dependencies: ["ST832", "ST559", "ST94", "ST755", "ST507", "ST38"])
    ]
)