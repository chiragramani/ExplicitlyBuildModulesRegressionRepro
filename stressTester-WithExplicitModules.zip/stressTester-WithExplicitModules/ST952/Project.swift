import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST952",
    targets: [
        makeLibraryTarget(name: "ST952", dependencies: ["ST38", "ST44"])
    ]
)