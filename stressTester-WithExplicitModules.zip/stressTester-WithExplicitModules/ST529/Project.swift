import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST529",
    targets: [
        makeLibraryTarget(name: "ST529", dependencies: ["ST28", "ST203"])
    ]
)