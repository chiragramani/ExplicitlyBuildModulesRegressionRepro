import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST226",
    targets: [
        makeLibraryTarget(name: "ST226", dependencies: ["ST162", "ST74", "ST102", "ST53", "ST20", "ST11", "ST4", "ST92", "ST44", "ST89", "ST96", "ST70", "ST26", "ST19"])
    ]
)