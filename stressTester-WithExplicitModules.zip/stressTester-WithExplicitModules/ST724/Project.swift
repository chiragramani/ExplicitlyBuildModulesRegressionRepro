import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST724",
    targets: [
        makeLibraryTarget(name: "ST724", dependencies: ["ST92", "ST722", "ST74", "ST546", "ST723", "ST26", "ST96", "ST38", "ST63"])
    ]
)