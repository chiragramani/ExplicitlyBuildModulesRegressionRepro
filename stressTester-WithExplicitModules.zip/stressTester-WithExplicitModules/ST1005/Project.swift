import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1005",
    targets: [
        makeLibraryTarget(name: "ST1005", dependencies: ["ST44", "ST38"])
    ]
)