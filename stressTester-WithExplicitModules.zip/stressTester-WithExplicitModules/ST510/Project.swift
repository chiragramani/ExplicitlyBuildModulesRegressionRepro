import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST510",
    targets: [
        makeLibraryTarget(name: "ST510", dependencies: ["ST509", "ST431", "ST138", "ST157", "ST136", "ST92", "ST74"])
    ]
)