import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST322",
    targets: [
        makeLibraryTarget(name: "ST322", dependencies: ["ST89", "ST138", "ST92", "ST20", "ST74", "ST87", "ST37", "ST96", "ST102", "ST26", "ST61", "ST131", "ST150", "ST23", "ST4", "ST99", "ST136", "ST142"])
    ]
)