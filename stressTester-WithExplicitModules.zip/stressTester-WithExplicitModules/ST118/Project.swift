import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST118",
    targets: [
        makeLibraryTarget(name: "ST118", dependencies: ["ST131", "ST23", "ST26", "ST188", "ST147", "ST189", "ST18", "ST53", "ST140", "ST38", "ST136", "ST190", "ST84", "ST128", "ST70", "ST138", "ST187", "ST89", "ST62", "ST180", "ST115", "ST137", "ST87", "ST129", "ST191", "ST52", "ST90", "ST33", "ST102", "ST92", "ST83", "ST37", "ST6", "ST167", "ST142", "ST20", "ST50", "ST44", "ST11", "ST27", "ST125", "ST72", "ST146", "ST192", "ST54", "ST161", "ST193", "ST7", "ST58", "ST25", "ST96", "ST194", "ST4", "ST145", "ST74"])
    ]
)