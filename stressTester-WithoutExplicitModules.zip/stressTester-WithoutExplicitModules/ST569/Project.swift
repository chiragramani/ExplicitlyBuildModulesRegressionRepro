import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST569",
    targets: [
        makeLibraryTarget(name: "ST569", dependencies: ["ST20", "ST146", "ST140", "ST138", "ST26", "ST145", "ST4", "ST74", "ST556", "ST150", "ST139", "ST323", "ST89", "ST131", "ST92", "ST96"])
    ]
)