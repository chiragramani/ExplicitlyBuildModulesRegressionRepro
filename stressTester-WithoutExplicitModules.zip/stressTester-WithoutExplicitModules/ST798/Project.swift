import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST798",
    targets: [
        makeLibraryTarget(name: "ST798", dependencies: ["ST531", "ST102", "ST530", "ST70", "ST68", "ST87", "ST690", "ST26", "ST20", "ST229", "ST92", "ST89"])
    ]
)