import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST4",
    targets: [
        makeLibraryTarget(name: "ST4", dependencies: ["ST529", "ST26", "ST1172", "ST1178"])
    ]
)