import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1072",
    targets: [
        makeLibraryTarget(name: "ST1072", dependencies: ["ST44", "ST38"])
    ]
)