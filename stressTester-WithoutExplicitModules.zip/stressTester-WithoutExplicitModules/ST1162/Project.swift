import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1162",
    targets: [
        makeLibraryTarget(name: "ST1162", dependencies: ["ST44", "ST38", "ST507"])
    ]
)