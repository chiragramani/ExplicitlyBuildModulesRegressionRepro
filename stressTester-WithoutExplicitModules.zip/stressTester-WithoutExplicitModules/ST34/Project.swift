import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST34",
    targets: [
        makeLibraryTarget(name: "ST34", dependencies: ["ST45", "ST25", "ST223", "ST89", "ST102", "ST18", "ST68", "ST261", "ST11", "ST164", "ST92", "ST468", "ST439", "ST30", "ST4", "ST17", "ST530", "ST70", "ST531", "ST270", "ST249", "ST253", "ST214", "ST96", "ST703", "ST774", "ST74", "ST20", "ST250", "ST524", "ST186", "ST26", "ST195", "ST450"])
    ]
)