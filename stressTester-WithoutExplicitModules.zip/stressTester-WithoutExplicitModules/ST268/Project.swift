import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST268",
    targets: [
        makeLibraryTarget(name: "ST268", dependencies: ["ST204", "ST26", "ST24", "ST192", "ST89", "ST4", "ST96", "ST58", "ST98", "ST20", "ST70", "ST534", "ST74", "ST45", "ST535", "ST92", "ST90", "ST230", "ST160", "ST102", "ST64", "ST81"])
    ]
)