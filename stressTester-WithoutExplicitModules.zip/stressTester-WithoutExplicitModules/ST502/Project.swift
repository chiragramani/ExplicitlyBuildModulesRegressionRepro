import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST502",
    targets: [
        makeLibraryTarget(name: "ST502", dependencies: ["ST812", "ST38", "ST92", "ST187", "ST196", "ST94", "ST74", "ST96", "ST507"])
    ]
)