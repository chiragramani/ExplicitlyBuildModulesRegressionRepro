import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST611",
    targets: [
        makeLibraryTarget(name: "ST611", dependencies: ["ST26", "ST87", "ST4", "ST68", "ST18", "ST96", "ST196", "ST92", "ST25", "ST187", "ST102", "ST70", "ST20", "ST74"])
    ]
)