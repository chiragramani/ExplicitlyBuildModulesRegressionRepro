import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST323",
    targets: [
        makeLibraryTarget(name: "ST323", dependencies: ["ST178", "ST150", "ST146", "ST96", "ST58", "ST176", "ST136", "ST92", "ST32", "ST90", "ST145", "ST89", "ST50", "ST139", "ST417", "ST23", "ST102", "ST138", "ST140", "ST74", "ST20", "ST148", "ST24", "ST142", "ST91", "ST76", "ST75", "ST62", "ST391", "ST70", "ST131", "ST49", "ST4", "ST87", "ST26"])
    ]
)