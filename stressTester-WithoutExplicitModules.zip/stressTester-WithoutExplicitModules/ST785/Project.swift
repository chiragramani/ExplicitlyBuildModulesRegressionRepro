import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST785",
    targets: [
        makeLibraryTarget(name: "ST785", dependencies: ["ST70", "ST68", "ST673", "ST611", "ST102", "ST4", "ST25", "ST92", "ST74", "ST278", "ST186", "ST18", "ST26", "ST214", "ST20", "ST96", "ST89", "ST253", "ST690", "ST587", "ST524", "ST87", "ST666"])
    ]
)