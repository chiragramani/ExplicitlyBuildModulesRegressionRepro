import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1060",
    targets: [
        makeLibraryTarget(name: "ST1060", dependencies: ["ST44", "ST38"])
    ]
)