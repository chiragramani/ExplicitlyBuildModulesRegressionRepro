import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST383",
    targets: [
        makeLibraryTarget(name: "ST383", dependencies: ["ST54", "ST384", "ST40", "ST742", "ST16", "ST238", "ST60", "ST28", "ST131", "ST417", "ST529", "ST26", "ST92", "ST96", "ST80", "ST61", "ST138", "ST388", "ST87", "ST67", "ST353", "ST71", "ST102", "ST240", "ST739", "ST88", "ST20", "ST74", "ST435", "ST4", "ST509", "ST187", "ST531", "ST530", "ST142", "ST148", "ST478", "ST139", "ST62", "ST258", "ST721", "ST136", "ST405", "ST241", "ST44", "ST8", "ST233", "ST539", "ST436", "ST38", "ST150", "ST427", "ST455", "ST232", "ST407", "ST387", "ST89", "ST37", "ST70", "ST196", "ST192", "ST189", "ST90", "ST257", "ST58", "ST23"])
    ]
)