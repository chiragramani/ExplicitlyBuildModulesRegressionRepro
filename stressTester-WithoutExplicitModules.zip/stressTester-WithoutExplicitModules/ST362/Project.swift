import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST362",
    targets: [
        makeLibraryTarget(name: "ST362", dependencies: ["ST138", "ST26", "ST438", "ST74", "ST38", "ST437", "ST150", "ST131", "ST23", "ST92", "ST96"])
    ]
)