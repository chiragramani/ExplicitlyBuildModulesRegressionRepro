import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1153",
    targets: [
        makeLibraryTarget(name: "ST1153", dependencies: ["ST507"])
    ]
)