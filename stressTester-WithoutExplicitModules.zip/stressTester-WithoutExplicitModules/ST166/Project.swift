import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST166",
    targets: [
        makeLibraryTarget(name: "ST166", dependencies: ["ST9", "ST762", "ST21", "ST78", "ST607"])
    ]
)