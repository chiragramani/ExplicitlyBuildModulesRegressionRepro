import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST50",
    targets: [
        makeLibraryTarget(name: "ST50", dependencies: ["ST44", "ST80", "ST4", "ST92", "ST96", "ST38", "ST537", "ST26", "ST74", "ST37", "ST65", "ST161", "ST192", "ST507"])
    ]
)