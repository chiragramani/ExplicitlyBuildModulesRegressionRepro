import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST731",
    targets: [
        makeLibraryTarget(name: "ST731", dependencies: ["ST264", "ST536", "ST80", "ST192", "ST600", "ST4", "ST44", "ST38", "ST26", "ST214"])
    ]
)