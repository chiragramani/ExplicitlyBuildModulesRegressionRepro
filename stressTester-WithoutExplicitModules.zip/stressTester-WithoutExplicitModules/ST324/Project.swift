import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST324",
    targets: [
        makeLibraryTarget(name: "ST324", dependencies: ["ST26", "ST131", "ST187", "ST92", "ST70", "ST89", "ST602", "ST418", "ST150", "ST138", "ST20", "ST4", "ST424", "ST102", "ST74", "ST583", "ST96", "ST552", "ST148", "ST364", "ST720", "ST441"])
    ]
)