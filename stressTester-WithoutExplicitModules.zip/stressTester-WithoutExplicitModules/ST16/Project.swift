import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST16",
    targets: [
        makeLibraryTarget(name: "ST16", dependencies: ["ST37", "ST26", "ST74", "ST23", "ST92", "ST4", "ST531", "ST96", "ST530", "ST258", "ST178", "ST436"])
    ]
)