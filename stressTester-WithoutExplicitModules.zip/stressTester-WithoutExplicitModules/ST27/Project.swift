import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST27",
    targets: [
        makeLibraryTarget(name: "ST27", dependencies: ["ST44", "ST535", "ST1160", "ST23", "ST1161", "ST1162", "ST38", "ST738", "ST4", "ST501", "ST80", "ST507", "ST26", "ST37", "ST205"])
    ]
)