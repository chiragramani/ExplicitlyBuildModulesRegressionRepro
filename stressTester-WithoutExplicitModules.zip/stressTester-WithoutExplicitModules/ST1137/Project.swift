import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1137",
    targets: [
        makeLibraryTarget(name: "ST1137", dependencies: ["ST44", "ST38"])
    ]
)