import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST227",
    targets: [
        makeLibraryTarget(name: "ST227", dependencies: ["ST26", "ST44", "ST38", "ST80", "ST536", "ST37", "ST4", "ST501", "ST27", "ST709", "ST537", "ST192"])
    ]
)