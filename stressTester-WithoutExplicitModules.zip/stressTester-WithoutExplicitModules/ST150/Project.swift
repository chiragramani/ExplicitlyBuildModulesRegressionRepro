import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST150",
    targets: [
        makeLibraryTarget(name: "ST150", dependencies: ["ST27", "ST137", "ST68", "ST140", "ST484", "ST44", "ST20", "ST275", "ST74", "ST30", "ST531", "ST428", "ST26", "ST19", "ST195", "ST54", "ST161", "ST192", "ST61", "ST4", "ST100", "ST223", "ST38", "ST50", "ST551", "ST417", "ST37", "ST454", "ST468", "ST102", "ST23", "ST452", "ST22", "ST543", "ST99", "ST524", "ST70", "ST214", "ST131", "ST589", "ST437", "ST148", "ST258", "ST91", "ST236", "ST152", "ST227", "ST89", "ST534", "ST138", "ST299", "ST87", "ST221", "ST512", "ST96", "ST65", "ST602", "ST448", "ST75", "ST615", "ST62", "ST220", "ST142", "ST538", "ST136", "ST72", "ST147", "ST5", "ST509", "ST735", "ST160", "ST139", "ST528", "ST241", "ST145", "ST92", "ST154"])
    ]
)