import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST736",
    targets: [
        makeLibraryTarget(name: "ST736", dependencies: ["ST92", "ST74", "ST102", "ST60", "ST484", "ST71", "ST89", "ST61", "ST26", "ST20", "ST54", "ST96", "ST38", "ST44"])
    ]
)