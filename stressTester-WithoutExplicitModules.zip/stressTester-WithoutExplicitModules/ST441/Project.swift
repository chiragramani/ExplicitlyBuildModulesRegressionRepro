import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST441",
    targets: [
        makeLibraryTarget(name: "ST441", dependencies: ["ST102", "ST20", "ST195", "ST70", "ST92", "ST430", "ST74", "ST26", "ST429", "ST99", "ST89", "ST100", "ST87", "ST4"])
    ]
)