import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST845",
    targets: [
        makeLibraryTarget(name: "ST845", dependencies: ["ST20", "ST531", "ST74", "ST530"])
    ]
)