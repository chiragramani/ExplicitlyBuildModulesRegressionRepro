import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST828",
    targets: [
        makeLibraryTarget(name: "ST828", dependencies: ["ST44", "ST38", "ST96"])
    ]
)