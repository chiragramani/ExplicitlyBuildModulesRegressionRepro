import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST931",
    targets: [
        makeLibraryTarget(name: "ST931", dependencies: ["ST44", "ST38"])
    ]
)