import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST605",
    targets: [
        makeLibraryTarget(name: "ST605", dependencies: ["ST364", "ST74", "ST92", "ST89", "ST134", "ST198"])
    ]
)