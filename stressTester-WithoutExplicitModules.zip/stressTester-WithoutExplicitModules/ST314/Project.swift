import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST314",
    targets: [
        makeLibraryTarget(name: "ST314", dependencies: ["ST315", "ST26", "ST376", "ST92", "ST178", "ST131", "ST150", "ST62", "ST20", "ST137", "ST227", "ST96", "ST49", "ST89", "ST23", "ST513", "ST139", "ST138", "ST90", "ST27", "ST74"])
    ]
)