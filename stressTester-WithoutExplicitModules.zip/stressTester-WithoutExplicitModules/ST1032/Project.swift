import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1032",
    targets: [
        makeLibraryTarget(name: "ST1032", dependencies: ["ST44", "ST38"])
    ]
)