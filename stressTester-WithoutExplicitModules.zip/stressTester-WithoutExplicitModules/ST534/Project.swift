import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST534",
    targets: [
        makeLibraryTarget(name: "ST534", dependencies: ["ST501", "ST4", "ST192", "ST80", "ST600", "ST26", "ST214", "ST38", "ST709", "ST65", "ST745", "ST536", "ST507", "ST44"])
    ]
)