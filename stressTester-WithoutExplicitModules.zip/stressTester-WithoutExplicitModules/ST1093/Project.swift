import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1093",
    targets: [
        makeLibraryTarget(name: "ST1093", dependencies: ["ST38", "ST44"])
    ]
)