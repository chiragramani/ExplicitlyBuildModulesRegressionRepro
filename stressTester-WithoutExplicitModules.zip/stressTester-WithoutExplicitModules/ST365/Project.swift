import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST365",
    targets: [
        makeLibraryTarget(name: "ST365", dependencies: ["ST423", "ST29", "ST131", "ST92", "ST26", "ST44"])
    ]
)