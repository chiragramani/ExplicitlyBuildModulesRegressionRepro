import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST292",
    targets: [
        makeLibraryTarget(name: "ST292", dependencies: ["ST442", "ST172", "ST29", "ST96", "ST422", "ST37", "ST89", "ST154", "ST142", "ST74", "ST92", "ST410", "ST26", "ST136", "ST131", "ST87", "ST62", "ST138", "ST44", "ST20", "ST196", "ST102", "ST4"])
    ]
)