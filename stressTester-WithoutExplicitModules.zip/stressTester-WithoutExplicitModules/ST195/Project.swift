import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST195",
    targets: [
        makeLibraryTarget(name: "ST195", dependencies: ["ST26"])
    ]
)