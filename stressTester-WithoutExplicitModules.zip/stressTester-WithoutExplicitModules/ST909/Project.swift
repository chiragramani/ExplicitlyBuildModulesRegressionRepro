import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST909",
    targets: [
        makeLibraryTarget(name: "ST909", dependencies: ["ST44", "ST38"])
    ]
)