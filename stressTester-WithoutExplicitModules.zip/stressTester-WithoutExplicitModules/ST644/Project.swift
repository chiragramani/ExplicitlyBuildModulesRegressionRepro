import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST644",
    targets: [
        makeLibraryTarget(name: "ST644", dependencies: ["ST507", "ST559", "ST38", "ST94"])
    ]
)