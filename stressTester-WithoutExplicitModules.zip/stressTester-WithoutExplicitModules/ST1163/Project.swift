import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1163",
    targets: [
        makeLibraryTarget(name: "ST1163", dependencies: ["ST876"])
    ]
)