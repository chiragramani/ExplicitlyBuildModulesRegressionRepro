import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1124",
    targets: [
        makeLibraryTarget(name: "ST1124", dependencies: ["ST38", "ST44"])
    ]
)