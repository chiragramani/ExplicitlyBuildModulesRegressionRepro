import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST28",
    targets: [
        makeLibraryTarget(name: "ST28", dependencies: ["ST876"])
    ]
)