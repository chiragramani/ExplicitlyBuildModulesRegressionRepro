import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST844",
    targets: [
        makeLibraryTarget(name: "ST844", dependencies: ["ST20", "ST102", "ST74", "ST96"])
    ]
)