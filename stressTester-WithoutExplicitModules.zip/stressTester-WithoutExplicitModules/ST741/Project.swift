import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST741",
    targets: [
        makeLibraryTarget(name: "ST741", dependencies: ["ST4", "ST531"])
    ]
)