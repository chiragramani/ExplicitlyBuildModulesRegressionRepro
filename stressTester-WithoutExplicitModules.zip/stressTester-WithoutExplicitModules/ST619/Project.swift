import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST619",
    targets: [
        makeLibraryTarget(name: "ST619", dependencies: ["ST74", "ST20", "ST583", "ST37", "ST92", "ST4"])
    ]
)