import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST217",
    targets: [
        makeLibraryTarget(name: "ST217", dependencies: ["ST187", "ST54", "ST26", "ST20", "ST192", "ST96", "ST223", "ST439", "ST589", "ST151", "ST92"])
    ]
)