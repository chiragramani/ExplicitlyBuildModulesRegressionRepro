import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST763",
    targets: [
        makeLibraryTarget(name: "ST763", dependencies: ["ST1167"])
    ]
)