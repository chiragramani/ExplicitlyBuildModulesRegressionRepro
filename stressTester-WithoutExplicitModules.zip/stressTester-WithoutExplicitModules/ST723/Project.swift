import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST723",
    targets: [
        makeLibraryTarget(name: "ST723", dependencies: ["ST4", "ST38", "ST26", "ST80", "ST44"])
    ]
)