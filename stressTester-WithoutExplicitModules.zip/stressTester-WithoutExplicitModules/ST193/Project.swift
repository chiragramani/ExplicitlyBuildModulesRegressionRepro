import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST193",
    targets: [
        makeLibraryTarget(name: "ST193", dependencies: ["ST129", "ST187", "ST290", "ST313", "ST297", "ST154", "ST538", "ST23", "ST539", "ST258", "ST271", "ST52", "ST175", "ST161", "ST540", "ST131", "ST394", "ST318", "ST425", "ST148", "ST334", "ST150", "ST189", "ST299", "ST43", "ST541", "ST351", "ST249", "ST62", "ST80", "ST265", "ST138", "ST324", "ST308", "ST542", "ST320", "ST192", "ST93", "ST37", "ST358", "ST96", "ST348", "ST543", "ST11", "ST294", "ST389", "ST352", "ST353", "ST544", "ST22", "ST72", "ST136", "ST379", "ST381", "ST545", "ST546", "ST384", "ST361", "ST386", "ST312", "ST90", "ST67", "ST26", "ST378", "ST16", "ST314", "ST547", "ST176", "ST436", "ST41", "ST4", "ST416", "ST548", "ST20", "ST549", "ST156", "ST376", "ST146", "ST38", "ST293", "ST390", "ST404", "ST424", "ST327", "ST550", "ST243", "ST68", "ST349", "ST448", "ST551", "ST74", "ST227", "ST267", "ST367", "ST76", "ST342", "ST30", "ST364", "ST257", "ST366", "ST213", "ST341", "ST223", "ST383", "ST552", "ST250", "ST63", "ST54", "ST535", "ST347", "ST345", "ST495", "ST338", "ST553", "ST554", "ST92", "ST241", "ST405", "ST291", "ST95", "ST89", "ST29", "ST319", "ST403", "ST336", "ST102", "ST48", "ST392", "ST137", "ST323", "ST40", "ST363", "ST337", "ST498", "ST406", "ST240", "ST49", "ST178", "ST412", "ST555", "ST452", "ST369"])
    ]
)