import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST939",
    targets: [
        makeLibraryTarget(name: "ST939", dependencies: ["ST38", "ST44"])
    ]
)