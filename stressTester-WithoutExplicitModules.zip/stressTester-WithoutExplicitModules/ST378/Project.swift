import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST378",
    targets: [
        makeLibraryTarget(name: "ST378", dependencies: ["ST44", "ST150", "ST26", "ST138", "ST131", "ST90", "ST96", "ST92", "ST38", "ST4", "ST74"])
    ]
)