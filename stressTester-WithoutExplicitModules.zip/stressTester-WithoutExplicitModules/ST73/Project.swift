import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST73",
    targets: [
        makeLibraryTarget(name: "ST73", dependencies: ["ST4", "ST96", "ST26", "ST80", "ST37", "ST74", "ST1150", "ST38", "ST187", "ST94", "ST92"])
    ]
)