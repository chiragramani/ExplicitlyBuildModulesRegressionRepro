import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1113",
    targets: [
        makeLibraryTarget(name: "ST1113", dependencies: ["ST44", "ST38"])
    ]
)