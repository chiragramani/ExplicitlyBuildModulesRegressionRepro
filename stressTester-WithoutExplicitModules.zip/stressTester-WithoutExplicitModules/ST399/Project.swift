import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST399",
    targets: [
        makeLibraryTarget(name: "ST399", dependencies: ["ST92", "ST53"])
    ]
)