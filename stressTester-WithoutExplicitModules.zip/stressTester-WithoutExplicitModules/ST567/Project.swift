import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST567",
    targets: [
        makeLibraryTarget(name: "ST567", dependencies: ["ST192", "ST140", "ST92", "ST23", "ST38", "ST138", "ST44", "ST20", "ST536", "ST74", "ST24", "ST4", "ST191", "ST535", "ST27", "ST96", "ST26", "ST80", "ST495"])
    ]
)