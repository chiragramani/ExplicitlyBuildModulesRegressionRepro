import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST602",
    targets: [
        makeLibraryTarget(name: "ST602", dependencies: ["ST5", "ST4", "ST74", "ST48"])
    ]
)