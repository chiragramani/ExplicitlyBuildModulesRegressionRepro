import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST643",
    targets: [
        makeLibraryTarget(name: "ST643", dependencies: ["ST44", "ST38"])
    ]
)