import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1136",
    targets: [
        makeLibraryTarget(name: "ST1136", dependencies: ["ST38", "ST44"])
    ]
)