import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST566",
    targets: [
        makeLibraryTarget(name: "ST566", dependencies: ["ST637", "ST38", "ST100", "ST203", "ST44", "ST92", "ST4", "ST23", "ST74", "ST26", "ST96"])
    ]
)