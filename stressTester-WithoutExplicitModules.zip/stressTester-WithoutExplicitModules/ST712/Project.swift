import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST712",
    targets: [
        makeLibraryTarget(name: "ST712", dependencies: ["ST26", "ST38", "ST44", "ST4", "ST80"])
    ]
)