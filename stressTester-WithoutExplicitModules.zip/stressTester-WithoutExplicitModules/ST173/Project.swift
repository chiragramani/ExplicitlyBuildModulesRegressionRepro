import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST173",
    targets: [
        makeLibraryTarget(name: "ST173", dependencies: ["ST26", "ST92", "ST880"])
    ]
)