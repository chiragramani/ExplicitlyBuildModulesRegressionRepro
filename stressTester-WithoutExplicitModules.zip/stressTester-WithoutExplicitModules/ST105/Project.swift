import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST105",
    targets: [
        makeLibraryTarget(name: "ST105", dependencies: ["ST31", "ST139", "ST138", "ST26", "ST75", "ST96", "ST7", "ST74", "ST20", "ST70", "ST140", "ST32", "ST102", "ST131", "ST4", "ST147", "ST89", "ST196", "ST137", "ST92", "ST126"])
    ]
)