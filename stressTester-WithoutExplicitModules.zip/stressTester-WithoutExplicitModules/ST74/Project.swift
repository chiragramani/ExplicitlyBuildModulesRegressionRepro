import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST74",
    targets: [
        makeLibraryTarget(name: "ST74", dependencies: ["ST26", "ST44"])
    ]
)