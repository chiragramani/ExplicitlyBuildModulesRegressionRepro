import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST543",
    targets: [
        makeLibraryTarget(name: "ST543", dependencies: ["ST80", "ST501", "ST909", "ST910", "ST911", "ST431", "ST536", "ST192", "ST507", "ST26", "ST4", "ST912", "ST44", "ST214", "ST38", "ST534"])
    ]
)