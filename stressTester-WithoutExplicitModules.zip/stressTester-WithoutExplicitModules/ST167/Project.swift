import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST167",
    targets: [
        makeLibraryTarget(name: "ST167", dependencies: ["ST4", "ST26", "ST44", "ST92", "ST80", "ST187", "ST38", "ST74", "ST96"])
    ]
)