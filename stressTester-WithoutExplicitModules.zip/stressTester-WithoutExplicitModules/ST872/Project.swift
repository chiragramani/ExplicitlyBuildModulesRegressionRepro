import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST872",
    targets: [
        makeLibraryTarget(name: "ST872", dependencies: [])
    ]
)