import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST412",
    targets: [
        makeLibraryTarget(name: "ST412", dependencies: ["ST386", "ST92", "ST334", "ST379", "ST20", "ST139", "ST327", "ST136", "ST4", "ST81", "ST635", "ST176", "ST96", "ST258", "ST102", "ST157", "ST178", "ST717", "ST32", "ST131", "ST74", "ST361", "ST413", "ST62", "ST416", "ST417", "ST148", "ST549", "ST551", "ST161", "ST187", "ST6", "ST531", "ST509", "ST90", "ST49", "ST452", "ST535", "ST192", "ST330", "ST138", "ST88", "ST425", "ST530", "ST383", "ST150", "ST405", "ST24", "ST142", "ST403", "ST38", "ST346", "ST37", "ST89", "ST65", "ST70", "ST87", "ST23", "ST376", "ST240", "ST91", "ST513", "ST172", "ST26", "ST190", "ST75", "ST58", "ST48", "ST11", "ST27"])
    ]
)