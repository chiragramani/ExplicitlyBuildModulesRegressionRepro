import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST312",
    targets: [
        makeLibraryTarget(name: "ST312", dependencies: ["ST531", "ST210", "ST755", "ST405", "ST195", "ST44", "ST532", "ST75", "ST37", "ST148", "ST62", "ST142", "ST74", "ST38", "ST92", "ST131", "ST223", "ST161", "ST20", "ST96", "ST417", "ST102", "ST436", "ST328", "ST11", "ST70", "ST54", "ST213", "ST89", "ST323", "ST32", "ST448", "ST376", "ST4", "ST530", "ST136", "ST138", "ST140", "ST87", "ST23", "ST26", "ST449", "ST150", "ST187"])
    ]
)