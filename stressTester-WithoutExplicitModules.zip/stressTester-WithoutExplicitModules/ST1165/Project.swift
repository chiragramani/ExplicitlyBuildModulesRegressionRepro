import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1165",
    targets: [
        makeLibraryTarget(name: "ST1165", dependencies: ["ST92", "ST74", "ST96", "ST26", "ST8", "ST566", "ST100", "ST430", "ST429", "ST20"])
    ]
)