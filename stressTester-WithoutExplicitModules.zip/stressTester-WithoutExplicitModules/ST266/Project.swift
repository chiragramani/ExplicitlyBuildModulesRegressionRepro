import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST266",
    targets: [
        makeLibraryTarget(name: "ST266", dependencies: ["ST525", "ST244", "ST38", "ST37", "ST20", "ST96", "ST697", "ST192", "ST18", "ST92", "ST24", "ST74", "ST70", "ST195", "ST25", "ST87", "ST214", "ST535", "ST102", "ST26", "ST489", "ST264", "ST4", "ST161", "ST89", "ST711", "ST44", "ST68", "ST710", "ST663"])
    ]
)