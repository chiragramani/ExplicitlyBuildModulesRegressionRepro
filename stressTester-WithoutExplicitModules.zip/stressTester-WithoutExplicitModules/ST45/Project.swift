import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST45",
    targets: [
        makeLibraryTarget(name: "ST45", dependencies: ["ST92", "ST524", "ST250", "ST657", "ST62", "ST253", "ST587", "ST225", "ST89", "ST703", "ST590", "ST195", "ST196", "ST102", "ST53", "ST75", "ST30", "ST54", "ST4", "ST430", "ST468", "ST23", "ST74", "ST87", "ST70", "ST96", "ST187", "ST530", "ST475", "ST259", "ST267", "ST494", "ST472", "ST593", "ST90", "ST513", "ST154", "ST534", "ST26", "ST99", "ST192", "ST88", "ST531", "ST220", "ST61", "ST100", "ST20", "ST44", "ST592", "ST19", "ST38", "ST68", "ST690", "ST155", "ST429", "ST666", "ST214"])
    ]
)