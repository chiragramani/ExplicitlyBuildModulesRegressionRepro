import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST35",
    targets: [
        makeLibraryTarget(name: "ST35", dependencies: ["ST65", "ST204", "ST96", "ST20", "ST90", "ST79", "ST205", "ST26", "ST74", "ST92"])
    ]
)