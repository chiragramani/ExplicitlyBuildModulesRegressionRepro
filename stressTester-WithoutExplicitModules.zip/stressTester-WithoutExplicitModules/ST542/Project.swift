import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST542",
    targets: [
        makeLibraryTarget(name: "ST542", dependencies: ["ST89", "ST161", "ST37", "ST70", "ST96", "ST20", "ST389", "ST74", "ST44", "ST138", "ST80", "ST26", "ST102", "ST38", "ST131", "ST4", "ST92", "ST90"])
    ]
)