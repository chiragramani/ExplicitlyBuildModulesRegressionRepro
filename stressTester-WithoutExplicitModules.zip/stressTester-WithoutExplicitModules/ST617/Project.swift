import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST617",
    targets: [
        makeLibraryTarget(name: "ST617", dependencies: ["ST26", "ST150", "ST92", "ST4", "ST93", "ST140", "ST96", "ST147", "ST20", "ST131"])
    ]
)