import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1069",
    targets: [
        makeLibraryTarget(name: "ST1069", dependencies: ["ST38", "ST44"])
    ]
)