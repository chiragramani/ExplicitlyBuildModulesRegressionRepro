import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST384",
    targets: [
        makeLibraryTarget(name: "ST384", dependencies: ["ST16", "ST150", "ST102", "ST88", "ST138", "ST89", "ST131", "ST26", "ST241", "ST38", "ST20", "ST87", "ST178", "ST23", "ST436", "ST37", "ST92", "ST96", "ST353", "ST4", "ST258", "ST70", "ST74"])
    ]
)