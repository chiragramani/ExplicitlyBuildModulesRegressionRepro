import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST889",
    targets: [
        makeLibraryTarget(name: "ST889", dependencies: [])
    ]
)