import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST415",
    targets: [
        makeLibraryTarget(name: "ST415", dependencies: ["ST150", "ST100", "ST20", "ST102", "ST26", "ST19", "ST131", "ST23", "ST509", "ST96", "ST496", "ST70", "ST138", "ST88", "ST54", "ST89", "ST640", "ST429", "ST92", "ST4", "ST38", "ST99", "ST74", "ST142", "ST136"])
    ]
)