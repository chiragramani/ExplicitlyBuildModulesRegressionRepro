import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST621",
    targets: [
        makeLibraryTarget(name: "ST621", dependencies: ["ST92", "ST187", "ST4", "ST48", "ST93", "ST74"])
    ]
)