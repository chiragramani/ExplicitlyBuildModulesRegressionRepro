import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST949",
    targets: [
        makeLibraryTarget(name: "ST949", dependencies: ["ST44", "ST38"])
    ]
)