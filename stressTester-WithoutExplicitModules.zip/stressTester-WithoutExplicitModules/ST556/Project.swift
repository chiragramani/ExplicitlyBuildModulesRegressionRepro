import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST556",
    targets: [
        makeLibraryTarget(name: "ST556", dependencies: ["ST131", "ST145", "ST23", "ST20", "ST516", "ST138", "ST179", "ST495", "ST154", "ST178", "ST26", "ST146", "ST4", "ST90", "ST530", "ST74", "ST92", "ST27", "ST96", "ST195", "ST62", "ST89", "ST531", "ST515", "ST144", "ST140", "ST70", "ST176", "ST558", "ST493", "ST187", "ST102"])
    ]
)