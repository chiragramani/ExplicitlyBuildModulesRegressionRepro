import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST18",
    targets: [
        makeLibraryTarget(name: "ST18", dependencies: ["ST74", "ST38", "ST263", "ST214", "ST96", "ST524", "ST92", "ST4"])
    ]
)