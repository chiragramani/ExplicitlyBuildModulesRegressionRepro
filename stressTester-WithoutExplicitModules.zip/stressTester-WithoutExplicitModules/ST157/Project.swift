import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST157",
    targets: [
        makeLibraryTarget(name: "ST157", dependencies: ["ST92", "ST24", "ST192", "ST102", "ST38", "ST74", "ST187", "ST431", "ST186", "ST535", "ST20", "ST26", "ST4", "ST96"])
    ]
)