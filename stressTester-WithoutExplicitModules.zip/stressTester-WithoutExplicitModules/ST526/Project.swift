import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST526",
    targets: [
        makeLibraryTarget(name: "ST526", dependencies: ["ST92"])
    ]
)