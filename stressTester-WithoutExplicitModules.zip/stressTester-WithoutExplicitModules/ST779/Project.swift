import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST779",
    targets: [
        makeLibraryTarget(name: "ST779", dependencies: ["ST87", "ST214", "ST593", "ST89", "ST68", "ST26", "ST4", "ST278", "ST102", "ST590", "ST74", "ST92", "ST20", "ST666", "ST96", "ST70"])
    ]
)