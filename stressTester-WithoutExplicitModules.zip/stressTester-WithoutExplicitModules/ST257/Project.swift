import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST257",
    targets: [
        makeLibraryTarget(name: "ST257", dependencies: ["ST4", "ST74", "ST552", "ST529", "ST92", "ST26", "ST833", "ST96", "ST195"])
    ]
)