import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST110",
    targets: [
        makeLibraryTarget(name: "ST110", dependencies: ["ST7", "ST136", "ST131", "ST26", "ST140", "ST141", "ST92", "ST74", "ST142", "ST87", "ST89", "ST138", "ST96", "ST54", "ST125", "ST4", "ST102"])
    ]
)