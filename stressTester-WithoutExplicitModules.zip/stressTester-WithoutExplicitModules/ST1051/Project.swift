import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1051",
    targets: [
        makeLibraryTarget(name: "ST1051", dependencies: ["ST44", "ST38"])
    ]
)