import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST308",
    targets: [
        makeLibraryTarget(name: "ST308", dependencies: ["ST20", "ST150", "ST194", "ST96", "ST142", "ST4", "ST136", "ST333", "ST743", "ST89", "ST744", "ST131", "ST38", "ST343", "ST147", "ST102", "ST161", "ST26", "ST74", "ST92", "ST138"])
    ]
)