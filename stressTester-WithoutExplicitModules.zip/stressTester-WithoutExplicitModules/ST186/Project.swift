import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST186",
    targets: [
        makeLibraryTarget(name: "ST186", dependencies: ["ST26", "ST532"])
    ]
)