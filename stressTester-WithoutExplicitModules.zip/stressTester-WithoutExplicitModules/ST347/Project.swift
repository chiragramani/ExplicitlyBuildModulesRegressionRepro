import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST347",
    targets: [
        makeLibraryTarget(name: "ST347", dependencies: ["ST75", "ST90", "ST102", "ST54", "ST376", "ST74", "ST138", "ST531", "ST139", "ST551", "ST96", "ST509", "ST192", "ST53", "ST447", "ST137", "ST153", "ST150", "ST70", "ST341", "ST87", "ST37", "ST92", "ST89", "ST149", "ST154", "ST196", "ST380", "ST23", "ST534", "ST45", "ST20", "ST32", "ST163", "ST140", "ST61", "ST213", "ST131", "ST136", "ST4", "ST530", "ST62", "ST187", "ST44", "ST223", "ST49", "ST65", "ST343", "ST11", "ST452", "ST194", "ST142", "ST26", "ST84"])
    ]
)