import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST476",
    targets: [
        makeLibraryTarget(name: "ST476", dependencies: ["ST475", "ST92", "ST468", "ST11", "ST26", "ST74", "ST30", "ST223"])
    ]
)