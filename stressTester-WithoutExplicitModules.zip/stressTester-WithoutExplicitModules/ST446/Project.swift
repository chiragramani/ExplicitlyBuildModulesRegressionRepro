import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST446",
    targets: [
        makeLibraryTarget(name: "ST446", dependencies: ["ST20", "ST92", "ST501", "ST80", "ST87", "ST26", "ST102", "ST192", "ST44", "ST89", "ST96", "ST38", "ST70", "ST74", "ST4"])
    ]
)