import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST181",
    targets: [
        makeLibraryTarget(name: "ST181", dependencies: ["ST5", "ST93"])
    ]
)