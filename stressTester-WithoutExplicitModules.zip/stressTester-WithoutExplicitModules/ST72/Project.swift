import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST72",
    targets: [
        makeLibraryTarget(name: "ST72", dependencies: ["ST41", "ST70", "ST592", "ST38", "ST54", "ST44", "ST92", "ST95", "ST735", "ST90", "ST196", "ST29", "ST96", "ST74", "ST596", "ST37", "ST192", "ST89", "ST163", "ST102", "ST187", "ST87", "ST20", "ST48", "ST26", "ST4"])
    ]
)