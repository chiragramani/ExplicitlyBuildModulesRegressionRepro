import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST628",
    targets: [
        makeLibraryTarget(name: "ST628", dependencies: ["ST430", "ST70", "ST99", "ST564", "ST100", "ST636", "ST8", "ST26", "ST429", "ST637", "ST20", "ST74", "ST4", "ST102", "ST89", "ST92"])
    ]
)