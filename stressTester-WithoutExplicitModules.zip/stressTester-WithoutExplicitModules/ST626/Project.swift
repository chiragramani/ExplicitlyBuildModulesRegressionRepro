import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST626",
    targets: [
        makeLibraryTarget(name: "ST626", dependencies: ["ST196", "ST74", "ST92", "ST70", "ST96", "ST102", "ST199", "ST20", "ST26"])
    ]
)