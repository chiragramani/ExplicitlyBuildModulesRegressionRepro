import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST725",
    targets: [
        makeLibraryTarget(name: "ST725", dependencies: ["ST37", "ST26"])
    ]
)