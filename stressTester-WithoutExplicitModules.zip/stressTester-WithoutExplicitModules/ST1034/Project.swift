import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1034",
    targets: [
        makeLibraryTarget(name: "ST1034", dependencies: ["ST44", "ST38"])
    ]
)