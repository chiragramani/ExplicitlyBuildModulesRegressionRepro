import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST86",
    targets: [
        makeLibraryTarget(name: "ST86", dependencies: ["ST80", "ST4", "ST44", "ST38", "ST26"])
    ]
)