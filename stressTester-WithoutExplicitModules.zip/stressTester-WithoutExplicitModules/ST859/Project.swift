import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST859",
    targets: [
        makeLibraryTarget(name: "ST859", dependencies: ["ST95", "ST87", "ST74", "ST92", "ST70", "ST586", "ST620", "ST102", "ST20", "ST850", "ST89", "ST26", "ST96", "ST38", "ST530", "ST44", "ST14", "ST531", "ST187", "ST4"])
    ]
)