import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST521",
    targets: [
        makeLibraryTarget(name: "ST521", dependencies: ["ST70", "ST229", "ST522", "ST74", "ST71", "ST520", "ST192", "ST102", "ST54", "ST26", "ST4", "ST87", "ST89", "ST38", "ST92", "ST61", "ST20", "ST96"])
    ]
)