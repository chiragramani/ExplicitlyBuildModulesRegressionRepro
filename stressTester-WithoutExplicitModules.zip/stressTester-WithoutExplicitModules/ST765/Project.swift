import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST765",
    targets: [
        makeLibraryTarget(name: "ST765", dependencies: ["ST764"])
    ]
)