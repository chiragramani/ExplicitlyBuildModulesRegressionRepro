import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST377",
    targets: [
        makeLibraryTarget(name: "ST377", dependencies: ["ST20", "ST92", "ST74", "ST229", "ST26", "ST142", "ST131"])
    ]
)