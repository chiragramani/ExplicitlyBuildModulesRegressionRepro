import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST307",
    targets: [
        makeLibraryTarget(name: "ST307", dependencies: ["ST427", "ST92", "ST27", "ST138", "ST131"])
    ]
)