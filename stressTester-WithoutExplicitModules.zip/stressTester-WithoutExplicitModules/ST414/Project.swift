import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST414",
    targets: [
        makeLibraryTarget(name: "ST414", dependencies: ["ST523", "ST250", "ST474", "ST89", "ST214", "ST150", "ST213", "ST26", "ST142", "ST102", "ST11", "ST136", "ST96", "ST267", "ST509", "ST223", "ST20", "ST468", "ST524", "ST131", "ST525", "ST74", "ST526", "ST92", "ST4", "ST527", "ST138", "ST473", "ST68"])
    ]
)