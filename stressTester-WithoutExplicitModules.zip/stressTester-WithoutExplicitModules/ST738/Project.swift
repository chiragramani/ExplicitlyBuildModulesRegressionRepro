import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST738",
    targets: [
        makeLibraryTarget(name: "ST738", dependencies: ["ST80", "ST4", "ST835", "ST529"])
    ]
)