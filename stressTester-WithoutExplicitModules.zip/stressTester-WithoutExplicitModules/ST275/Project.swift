import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST275",
    targets: [
        makeLibraryTarget(name: "ST275", dependencies: ["ST92", "ST191", "ST38", "ST44", "ST65", "ST584", "ST501", "ST507", "ST80", "ST178", "ST593", "ST74", "ST543", "ST54", "ST192", "ST23", "ST189", "ST214", "ST4", "ST596", "ST20", "ST26", "ST96", "ST601"])
    ]
)