import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST580",
    targets: [
        makeLibraryTarget(name: "ST580", dependencies: ["ST102", "ST23", "ST137", "ST452", "ST92", "ST139", "ST49", "ST74", "ST80", "ST70", "ST376", "ST44", "ST38", "ST131", "ST138", "ST20", "ST26", "ST4", "ST90", "ST96", "ST89", "ST150", "ST62"])
    ]
)