import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1131",
    targets: [
        makeLibraryTarget(name: "ST1131", dependencies: ["ST38", "ST44"])
    ]
)