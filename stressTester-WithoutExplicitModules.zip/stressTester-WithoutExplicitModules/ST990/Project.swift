import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST990",
    targets: [
        makeLibraryTarget(name: "ST990", dependencies: ["ST38", "ST44"])
    ]
)