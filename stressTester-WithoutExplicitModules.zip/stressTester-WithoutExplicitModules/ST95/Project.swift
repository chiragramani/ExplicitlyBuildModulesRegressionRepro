import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST95",
    targets: [
        makeLibraryTarget(name: "ST95", dependencies: ["ST13", "ST738", "ST835", "ST1163", "ST80", "ST92", "ST529", "ST187", "ST96", "ST876"])
    ]
)