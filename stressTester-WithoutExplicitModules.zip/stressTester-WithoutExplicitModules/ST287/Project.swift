import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST287",
    targets: [
        makeLibraryTarget(name: "ST287", dependencies: ["ST92", "ST150", "ST391", "ST96", "ST187", "ST138", "ST194", "ST146", "ST26", "ST27", "ST89", "ST102", "ST139", "ST23", "ST20", "ST74", "ST70", "ST87", "ST176", "ST131", "ST141"])
    ]
)