import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST924",
    targets: [
        makeLibraryTarget(name: "ST924", dependencies: ["ST38", "ST44"])
    ]
)