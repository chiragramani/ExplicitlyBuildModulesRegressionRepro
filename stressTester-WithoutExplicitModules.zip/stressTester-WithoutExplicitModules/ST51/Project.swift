import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST51",
    targets: [
        makeLibraryTarget(name: "ST51", dependencies: ["ST38", "ST638", "ST639", "ST89", "ST20", "ST92", "ST37", "ST44", "ST96", "ST507", "ST70", "ST4", "ST65", "ST26", "ST74", "ST196", "ST80", "ST102", "ST48", "ST161"])
    ]
)