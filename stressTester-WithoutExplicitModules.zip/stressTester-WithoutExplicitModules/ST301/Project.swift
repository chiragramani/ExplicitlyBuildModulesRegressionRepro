import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST301",
    targets: [
        makeLibraryTarget(name: "ST301", dependencies: ["ST74", "ST429", "ST27", "ST138", "ST640", "ST102", "ST70", "ST530", "ST154", "ST509", "ST187", "ST38", "ST44", "ST96", "ST417", "ST100", "ST267", "ST99", "ST140", "ST89", "ST136", "ST88", "ST195", "ST68", "ST11", "ST150", "ST148", "ST496", "ST8", "ST430", "ST531", "ST54", "ST23", "ST131", "ST4", "ST641", "ST180", "ST20", "ST642", "ST19", "ST142", "ST26", "ST92", "ST342"])
    ]
)