import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST970",
    targets: [
        makeLibraryTarget(name: "ST970", dependencies: ["ST44", "ST38"])
    ]
)