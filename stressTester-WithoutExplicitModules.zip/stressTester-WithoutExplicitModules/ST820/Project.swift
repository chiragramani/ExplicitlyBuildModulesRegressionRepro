import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST820",
    targets: [
        makeLibraryTarget(name: "ST820", dependencies: ["ST535", "ST80", "ST44", "ST205", "ST4", "ST38", "ST26"])
    ]
)