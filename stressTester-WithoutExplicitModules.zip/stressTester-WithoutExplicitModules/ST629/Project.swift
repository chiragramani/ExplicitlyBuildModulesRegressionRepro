import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST629",
    targets: [
        makeLibraryTarget(name: "ST629", dependencies: ["ST20", "ST4", "ST89", "ST70", "ST102", "ST26", "ST615", "ST37", "ST92"])
    ]
)