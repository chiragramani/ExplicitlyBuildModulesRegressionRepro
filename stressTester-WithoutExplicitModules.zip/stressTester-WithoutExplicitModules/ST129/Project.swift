import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST129",
    targets: [
        makeLibraryTarget(name: "ST129", dependencies: ["ST138", "ST131", "ST92", "ST102", "ST26"])
    ]
)