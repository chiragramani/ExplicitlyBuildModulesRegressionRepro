import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST817",
    targets: [
        makeLibraryTarget(name: "ST817", dependencies: [])
    ]
)