import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST874",
    targets: [
        makeLibraryTarget(name: "ST874", dependencies: [])
    ]
)