import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST245",
    targets: [
        makeLibraryTarget(name: "ST245", dependencies: ["ST96", "ST38", "ST26", "ST102", "ST71", "ST531", "ST80", "ST497", "ST61", "ST530", "ST54", "ST4", "ST92", "ST498", "ST48", "ST20", "ST87", "ST196", "ST74", "ST70", "ST44", "ST89"])
    ]
)