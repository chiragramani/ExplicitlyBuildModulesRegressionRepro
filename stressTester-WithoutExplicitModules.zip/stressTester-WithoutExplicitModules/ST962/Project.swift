import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST962",
    targets: [
        makeLibraryTarget(name: "ST962", dependencies: ["ST44", "ST38"])
    ]
)