import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST93",
    targets: [
        makeLibraryTarget(name: "ST93", dependencies: ["ST1163", "ST835", "ST529", "ST28", "ST876", "ST203"])
    ]
)