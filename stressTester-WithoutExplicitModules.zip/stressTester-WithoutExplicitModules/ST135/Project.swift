import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST135",
    targets: [
        makeLibraryTarget(name: "ST135", dependencies: ["ST143", "ST27", "ST138", "ST140", "ST38", "ST96", "ST131", "ST74", "ST753", "ST23", "ST26", "ST92", "ST178", "ST4"])
    ]
)