import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST26",
    targets: [
        makeLibraryTarget(name: "ST26", dependencies: [])
    ]
)