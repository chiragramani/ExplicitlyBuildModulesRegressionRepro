import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1112",
    targets: [
        makeLibraryTarget(name: "ST1112", dependencies: ["ST44", "ST38"])
    ]
)