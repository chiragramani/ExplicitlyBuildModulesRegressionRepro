import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST349",
    targets: [
        makeLibraryTarget(name: "ST349", dependencies: ["ST37", "ST92", "ST147", "ST196", "ST96", "ST87", "ST102", "ST529", "ST539", "ST54", "ST4", "ST70", "ST26", "ST735", "ST131", "ST52", "ST161", "ST74", "ST20", "ST142", "ST258", "ST138", "ST41", "ST38", "ST150", "ST89", "ST538", "ST72"])
    ]
)