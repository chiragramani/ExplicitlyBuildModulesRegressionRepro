import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST128",
    targets: [
        makeLibraryTarget(name: "ST128", dependencies: ["ST136", "ST138", "ST92", "ST142"])
    ]
)