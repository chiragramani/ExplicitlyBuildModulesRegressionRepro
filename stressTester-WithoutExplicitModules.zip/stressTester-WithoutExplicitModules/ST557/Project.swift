import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST557",
    targets: [
        makeLibraryTarget(name: "ST557", dependencies: ["ST23", "ST1144", "ST74", "ST92", "ST44", "ST37", "ST38", "ST96", "ST181", "ST1146", "ST26", "ST1145", "ST4", "ST48"])
    ]
)