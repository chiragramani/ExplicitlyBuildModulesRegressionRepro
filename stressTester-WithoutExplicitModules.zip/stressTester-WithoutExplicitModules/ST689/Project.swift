import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST689",
    targets: [
        makeLibraryTarget(name: "ST689", dependencies: ["ST693", "ST20", "ST100", "ST96", "ST430", "ST26", "ST92", "ST102", "ST636", "ST99", "ST89"])
    ]
)