import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST189",
    targets: [
        makeLibraryTarget(name: "ST189", dependencies: ["ST536", "ST838", "ST38", "ST192", "ST507", "ST44"])
    ]
)