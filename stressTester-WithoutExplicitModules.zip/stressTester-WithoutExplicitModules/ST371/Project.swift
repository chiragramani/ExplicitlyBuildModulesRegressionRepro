import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST371",
    targets: [
        makeLibraryTarget(name: "ST371", dependencies: ["ST142", "ST26", "ST20", "ST277", "ST92"])
    ]
)