import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST398",
    targets: [
        makeLibraryTarget(name: "ST398", dependencies: ["ST399", "ST131", "ST148", "ST76", "ST26", "ST284", "ST67", "ST53", "ST96", "ST136", "ST20", "ST102", "ST32", "ST74", "ST75", "ST92", "ST89", "ST192", "ST70"])
    ]
)