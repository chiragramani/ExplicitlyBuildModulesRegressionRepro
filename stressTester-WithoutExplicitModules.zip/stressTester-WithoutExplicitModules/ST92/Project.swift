import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST92",
    targets: [
        makeLibraryTarget(name: "ST92", dependencies: ["ST729", "ST80", "ST37", "ST74", "ST5", "ST186", "ST96", "ST26", "ST44", "ST4", "ST615", "ST265", "ST532", "ST65", "ST625", "ST38", "ST195", "ST93", "ST89", "ST59", "ST190", "ST48", "ST187", "ST77", "ST181", "ST82", "ST875", "ST602"])
    ]
)