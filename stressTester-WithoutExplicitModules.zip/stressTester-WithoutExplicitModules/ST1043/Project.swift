import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1043",
    targets: [
        makeLibraryTarget(name: "ST1043", dependencies: ["ST44", "ST38"])
    ]
)