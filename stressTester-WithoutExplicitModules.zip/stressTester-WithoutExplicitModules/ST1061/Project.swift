import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1061",
    targets: [
        makeLibraryTarget(name: "ST1061", dependencies: ["ST44", "ST38"])
    ]
)