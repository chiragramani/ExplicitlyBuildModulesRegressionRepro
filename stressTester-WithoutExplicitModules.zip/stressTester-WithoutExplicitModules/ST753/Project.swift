import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST753",
    targets: [
        makeLibraryTarget(name: "ST753", dependencies: ["ST74", "ST23", "ST187", "ST96", "ST26"])
    ]
)