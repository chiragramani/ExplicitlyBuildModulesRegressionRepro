import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST914",
    targets: [
        makeLibraryTarget(name: "ST914", dependencies: ["ST38", "ST44"])
    ]
)