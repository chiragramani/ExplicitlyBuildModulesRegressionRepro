import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST560",
    targets: [
        makeLibraryTarget(name: "ST560", dependencies: ["ST507"])
    ]
)