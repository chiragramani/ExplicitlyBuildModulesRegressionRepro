import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST478",
    targets: [
        makeLibraryTarget(name: "ST478", dependencies: ["ST96", "ST530", "ST484", "ST192", "ST74", "ST102", "ST87", "ST60", "ST38", "ST92", "ST54", "ST482", "ST44", "ST89", "ST479", "ST483", "ST531", "ST20", "ST196", "ST195", "ST736", "ST26", "ST23", "ST4", "ST70"])
    ]
)