import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST449",
    targets: [
        makeLibraryTarget(name: "ST449", dependencies: ["ST531", "ST96", "ST37", "ST4", "ST38", "ST92", "ST530", "ST102", "ST89", "ST213", "ST430", "ST11", "ST217", "ST100", "ST524", "ST439", "ST491", "ST26", "ST187", "ST223", "ST444", "ST529", "ST44", "ST20", "ST448", "ST640", "ST68", "ST74", "ST566", "ST254", "ST151", "ST589", "ST450", "ST99", "ST87", "ST70", "ST429", "ST61", "ST443"])
    ]
)