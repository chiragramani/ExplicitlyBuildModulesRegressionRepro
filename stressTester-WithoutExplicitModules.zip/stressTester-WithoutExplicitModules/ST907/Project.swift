import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST907",
    targets: [
        makeLibraryTarget(name: "ST907", dependencies: [])
    ]
)