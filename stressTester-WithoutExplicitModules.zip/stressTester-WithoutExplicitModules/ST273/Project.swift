import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST273",
    targets: [
        makeLibraryTarget(name: "ST273", dependencies: ["ST192", "ST690", "ST264", "ST18", "ST102", "ST524", "ST4", "ST89", "ST466", "ST587", "ST87", "ST74", "ST666", "ST61", "ST214", "ST70", "ST68", "ST92", "ST20", "ST468", "ST731", "ST278", "ST38", "ST26", "ST37", "ST25", "ST96", "ST162", "ST88", "ST84"])
    ]
)