import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST940",
    targets: [
        makeLibraryTarget(name: "ST940", dependencies: ["ST44", "ST38"])
    ]
)