import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST575",
    targets: [
        makeLibraryTarget(name: "ST575", dependencies: ["ST96", "ST92", "ST87", "ST20", "ST102", "ST167", "ST26", "ST147", "ST89", "ST4", "ST70", "ST150", "ST131", "ST196", "ST529", "ST38", "ST138", "ST12"])
    ]
)