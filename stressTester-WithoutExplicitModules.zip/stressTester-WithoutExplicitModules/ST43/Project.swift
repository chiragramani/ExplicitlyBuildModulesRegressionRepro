import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST43",
    targets: [
        makeLibraryTarget(name: "ST43", dependencies: ["ST4", "ST76", "ST92", "ST37", "ST38", "ST161", "ST44", "ST90", "ST26", "ST96", "ST74"])
    ]
)