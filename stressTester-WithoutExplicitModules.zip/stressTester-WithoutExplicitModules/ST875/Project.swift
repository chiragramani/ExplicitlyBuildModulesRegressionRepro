import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST875",
    targets: [
        makeLibraryTarget(name: "ST875", dependencies: ["ST874", "ST876"])
    ]
)