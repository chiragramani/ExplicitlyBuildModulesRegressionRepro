import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST331",
    targets: [
        makeLibraryTarget(name: "ST331", dependencies: ["ST26", "ST138"])
    ]
)