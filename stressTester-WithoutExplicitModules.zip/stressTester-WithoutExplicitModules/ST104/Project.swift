import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST104",
    targets: [
        makeLibraryTarget(name: "ST104", dependencies: ["ST136", "ST92"])
    ]
)