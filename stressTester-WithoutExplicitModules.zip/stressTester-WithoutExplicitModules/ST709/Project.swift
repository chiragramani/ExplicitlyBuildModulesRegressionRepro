import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST709",
    targets: [
        makeLibraryTarget(name: "ST709", dependencies: ["ST44", "ST38", "ST507", "ST738"])
    ]
)