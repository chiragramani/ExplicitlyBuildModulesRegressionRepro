import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1107",
    targets: [
        makeLibraryTarget(name: "ST1107", dependencies: ["ST44", "ST38"])
    ]
)