import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST430",
    targets: [
        makeLibraryTarget(name: "ST430", dependencies: ["ST8", "ST26", "ST637", "ST4", "ST96", "ST100", "ST195", "ST532", "ST101", "ST74", "ST92"])
    ]
)