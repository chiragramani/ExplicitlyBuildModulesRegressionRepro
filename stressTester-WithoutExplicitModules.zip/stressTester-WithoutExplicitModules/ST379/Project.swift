import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST379",
    targets: [
        makeLibraryTarget(name: "ST379", dependencies: ["ST80", "ST138", "ST4", "ST74", "ST96", "ST62", "ST102", "ST20", "ST89", "ST44", "ST187", "ST38", "ST131", "ST92", "ST192", "ST535", "ST26", "ST24", "ST70"])
    ]
)