import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST397",
    targets: [
        makeLibraryTarget(name: "ST397", dependencies: ["ST137", "ST417", "ST62", "ST583", "ST37", "ST509", "ST38", "ST398", "ST146", "ST528", "ST176", "ST196", "ST4", "ST543", "ST54", "ST88", "ST27", "ST150", "ST23", "ST513", "ST131", "ST87", "ST20", "ST74", "ST551", "ST139", "ST96", "ST102", "ST138", "ST89", "ST92", "ST136", "ST6", "ST400", "ST399", "ST376", "ST70", "ST26", "ST90", "ST401", "ST141", "ST44", "ST142", "ST584"])
    ]
)