import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST866",
    targets: [
        makeLibraryTarget(name: "ST866", dependencies: ["ST74", "ST4", "ST70", "ST20", "ST624", "ST102", "ST89", "ST14", "ST54", "ST92", "ST26", "ST530", "ST531", "ST850", "ST96"])
    ]
)