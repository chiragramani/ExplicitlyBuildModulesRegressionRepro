import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST791",
    targets: [
        makeLibraryTarget(name: "ST791", dependencies: ["ST26", "ST590", "ST253", "ST96", "ST666", "ST87", "ST70", "ST214", "ST587", "ST89", "ST102", "ST593", "ST690", "ST25", "ST92", "ST162", "ST264", "ST792", "ST524", "ST18", "ST278", "ST657", "ST533", "ST74", "ST20", "ST4", "ST68"])
    ]
)