import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST783",
    targets: [
        makeLibraryTarget(name: "ST783", dependencies: ["ST38", "ST214", "ST20", "ST690", "ST666", "ST87", "ST74", "ST102", "ST96", "ST68", "ST611", "ST4", "ST25", "ST92", "ST278", "ST18", "ST26", "ST89", "ST587", "ST653", "ST524"])
    ]
)