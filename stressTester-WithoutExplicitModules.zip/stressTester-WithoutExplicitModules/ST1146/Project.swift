import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1146",
    targets: [
        makeLibraryTarget(name: "ST1146", dependencies: ["ST80", "ST38", "ST4", "ST26", "ST44"])
    ]
)