import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST762",
    targets: [
        makeLibraryTarget(name: "ST762", dependencies: ["ST201", "ST78", "ST9"])
    ]
)