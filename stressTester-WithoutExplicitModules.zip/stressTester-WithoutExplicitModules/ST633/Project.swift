import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST633",
    targets: [
        makeLibraryTarget(name: "ST633", dependencies: [])
    ]
)