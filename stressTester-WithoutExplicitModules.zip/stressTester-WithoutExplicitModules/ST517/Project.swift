import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST517",
    targets: [
        makeLibraryTarget(name: "ST517", dependencies: [])
    ]
)