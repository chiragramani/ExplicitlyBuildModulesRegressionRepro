import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST295",
    targets: [
        makeLibraryTarget(name: "ST295", dependencies: ["ST531", "ST131", "ST136", "ST138", "ST142", "ST509", "ST161", "ST27", "ST102", "ST74", "ST20", "ST92", "ST4", "ST96", "ST38", "ST192", "ST87", "ST37", "ST44", "ST89", "ST195", "ST26", "ST70", "ST530"])
    ]
)