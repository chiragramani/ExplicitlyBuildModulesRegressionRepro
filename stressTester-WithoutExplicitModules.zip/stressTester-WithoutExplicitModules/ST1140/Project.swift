import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1140",
    targets: [
        makeLibraryTarget(name: "ST1140", dependencies: ["ST96", "ST810", "ST530", "ST531"])
    ]
)