import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST103",
    targets: [
        makeLibraryTarget(name: "ST103", dependencies: ["ST104", "ST38", "ST26", "ST187", "ST89", "ST102", "ST54", "ST45", "ST199", "ST138", "ST60", "ST20", "ST74", "ST92", "ST4", "ST90", "ST136", "ST96", "ST192", "ST81", "ST39", "ST142", "ST70", "ST24", "ST87", "ST131", "ST195", "ST200", "ST201"])
    ]
)