import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST574",
    targets: [
        makeLibraryTarget(name: "ST574", dependencies: ["ST347", "ST312", "ST131", "ST92", "ST150", "ST318", "ST322", "ST367", "ST341", "ST412", "ST343", "ST342", "ST75", "ST575", "ST576", "ST340", "ST297"])
    ]
)