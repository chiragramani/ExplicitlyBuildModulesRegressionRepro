import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST559",
    targets: [
        makeLibraryTarget(name: "ST559", dependencies: ["ST507"])
    ]
)