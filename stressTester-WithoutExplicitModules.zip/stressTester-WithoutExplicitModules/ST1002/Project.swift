import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1002",
    targets: [
        makeLibraryTarget(name: "ST1002", dependencies: ["ST38", "ST44"])
    ]
)