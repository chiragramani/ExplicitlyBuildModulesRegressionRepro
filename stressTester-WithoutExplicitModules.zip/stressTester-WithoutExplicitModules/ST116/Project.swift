import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST116",
    targets: [
        makeLibraryTarget(name: "ST116", dependencies: ["ST92", "ST20", "ST127", "ST26", "ST89", "ST70", "ST38", "ST96", "ST4", "ST130", "ST142", "ST170", "ST102", "ST612", "ST36", "ST487", "ST15"])
    ]
)