import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST156",
    targets: [
        makeLibraryTarget(name: "ST156", dependencies: ["ST96", "ST74", "ST552", "ST38", "ST26", "ST4", "ST92", "ST529", "ST44"])
    ]
)