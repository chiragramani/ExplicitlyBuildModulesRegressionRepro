import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST21",
    targets: [
        makeLibraryTarget(name: "ST21", dependencies: ["ST764", "ST765", "ST766", "ST608", "ST46"])
    ]
)