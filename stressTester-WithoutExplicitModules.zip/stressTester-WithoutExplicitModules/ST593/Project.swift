import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST593",
    targets: [
        makeLibraryTarget(name: "ST593", dependencies: ["ST38", "ST600", "ST592", "ST26", "ST4", "ST44", "ST214", "ST80"])
    ]
)