import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST592",
    targets: [
        makeLibraryTarget(name: "ST592", dependencies: ["ST600", "ST507", "ST38", "ST44"])
    ]
)