import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST281",
    targets: [
        makeLibraryTarget(name: "ST281", dependencies: ["ST586", "ST14", "ST68", "ST864", "ST89", "ST854", "ST866", "ST20", "ST96", "ST4", "ST857", "ST92", "ST283", "ST624", "ST855", "ST87", "ST74", "ST853", "ST863", "ST620", "ST860", "ST102", "ST54", "ST44", "ST861", "ST70", "ST859", "ST38", "ST862", "ST26", "ST850", "ST260"])
    ]
)