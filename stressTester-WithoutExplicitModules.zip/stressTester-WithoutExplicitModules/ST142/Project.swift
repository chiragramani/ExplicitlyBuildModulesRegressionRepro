import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST142",
    targets: [
        makeLibraryTarget(name: "ST142", dependencies: ["ST26", "ST54", "ST96", "ST44", "ST138", "ST136", "ST27", "ST487", "ST4", "ST131", "ST92", "ST20", "ST187"])
    ]
)