import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST528",
    targets: [
        makeLibraryTarget(name: "ST528", dependencies: ["ST89", "ST37", "ST513", "ST88", "ST495", "ST92", "ST26", "ST438", "ST176", "ST96", "ST437", "ST20", "ST102", "ST23", "ST87", "ST74", "ST4", "ST192", "ST62"])
    ]
)