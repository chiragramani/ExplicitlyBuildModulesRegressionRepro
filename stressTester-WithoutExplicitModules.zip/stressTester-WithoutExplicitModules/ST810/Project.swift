import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST810",
    targets: [
        makeLibraryTarget(name: "ST810", dependencies: ["ST531", "ST96", "ST530", "ST74"])
    ]
)