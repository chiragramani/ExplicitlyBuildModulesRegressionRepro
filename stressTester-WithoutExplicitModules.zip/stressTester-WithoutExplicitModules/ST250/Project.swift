import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST250",
    targets: [
        makeLibraryTarget(name: "ST250", dependencies: ["ST80", "ST25", "ST264", "ST173", "ST592", "ST697", "ST466", "ST192", "ST44", "ST524", "ST102", "ST475", "ST18", "ST666", "ST489", "ST267", "ST593", "ST610", "ST162", "ST221", "ST242", "ST468", "ST20", "ST523", "ST771", "ST61", "ST220", "ST657", "ST37", "ST590", "ST54", "ST68", "ST225", "ST694", "ST99", "ST214", "ST600", "ST591", "ST703", "ST587", "ST490", "ST17", "ST164", "ST87", "ST430", "ST740", "ST38", "ST30", "ST533", "ST187", "ST253", "ST100", "ST65", "ST74", "ST501", "ST96", "ST244", "ST92", "ST690", "ST4", "ST208", "ST278", "ST26", "ST429", "ST48", "ST273", "ST174", "ST84", "ST89", "ST70"])
    ]
)