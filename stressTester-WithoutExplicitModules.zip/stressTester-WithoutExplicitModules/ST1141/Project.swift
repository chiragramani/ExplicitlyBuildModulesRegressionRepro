import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1141",
    targets: [
        makeLibraryTarget(name: "ST1141", dependencies: ["ST507", "ST1156"])
    ]
)