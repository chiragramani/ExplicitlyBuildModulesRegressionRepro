import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST770",
    targets: [
        makeLibraryTarget(name: "ST770", dependencies: ["ST192"])
    ]
)