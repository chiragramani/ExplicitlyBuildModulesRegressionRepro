import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST588",
    targets: [
        makeLibraryTarget(name: "ST588", dependencies: ["ST38", "ST44"])
    ]
)