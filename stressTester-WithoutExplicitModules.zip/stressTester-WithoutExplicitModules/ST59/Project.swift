import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST59",
    targets: [
        makeLibraryTarget(name: "ST59", dependencies: ["ST74", "ST4", "ST48", "ST44", "ST907", "ST96"])
    ]
)