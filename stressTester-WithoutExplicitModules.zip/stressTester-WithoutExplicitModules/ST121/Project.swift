import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST121",
    targets: [
        makeLibraryTarget(name: "ST121", dependencies: ["ST75", "ST92", "ST136", "ST53", "ST4", "ST32", "ST27", "ST20", "ST192", "ST7", "ST137", "ST70", "ST74", "ST138", "ST23", "ST139", "ST96", "ST131", "ST58", "ST89", "ST140", "ST12", "ST26", "ST187", "ST126"])
    ]
)