import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST784",
    targets: [
        makeLibraryTarget(name: "ST784", dependencies: ["ST278", "ST92", "ST96", "ST68", "ST89", "ST666", "ST74"])
    ]
)