import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST58",
    targets: [
        makeLibraryTarget(name: "ST58", dependencies: ["ST192", "ST38", "ST26", "ST74", "ST92", "ST186", "ST50", "ST37", "ST4", "ST44", "ST190", "ST89", "ST96", "ST102", "ST20"])
    ]
)