import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST32",
    targets: [
        makeLibraryTarget(name: "ST32", dependencies: ["ST96", "ST4", "ST74", "ST102", "ST26", "ST37", "ST161", "ST192", "ST48", "ST20", "ST38", "ST75", "ST92", "ST44"])
    ]
)