import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST471",
    targets: [
        makeLibraryTarget(name: "ST471", dependencies: ["ST20", "ST87", "ST38", "ST102", "ST89", "ST214", "ST489", "ST92", "ST524", "ST600", "ST468", "ST593", "ST74", "ST196", "ST96", "ST250", "ST590", "ST61", "ST267", "ST26", "ST162", "ST244", "ST4", "ST666", "ST68", "ST192", "ST70"])
    ]
)