import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST680",
    targets: [
        makeLibraryTarget(name: "ST680", dependencies: ["ST667", "ST701", "ST4", "ST89", "ST74", "ST92", "ST96", "ST90", "ST68", "ST102", "ST596", "ST81", "ST195", "ST24", "ST187", "ST70", "ST26", "ST244", "ST20", "ST214", "ST87"])
    ]
)