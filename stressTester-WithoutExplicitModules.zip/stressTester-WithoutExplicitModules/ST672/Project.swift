import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST672",
    targets: [
        makeLibraryTarget(name: "ST672", dependencies: ["ST685", "ST89", "ST187", "ST600", "ST96", "ST74", "ST102", "ST26", "ST92", "ST20", "ST4", "ST214"])
    ]
)