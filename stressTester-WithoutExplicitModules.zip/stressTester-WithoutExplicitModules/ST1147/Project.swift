import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1147",
    targets: [
        makeLibraryTarget(name: "ST1147", dependencies: ["ST532", "ST186", "ST26"])
    ]
)