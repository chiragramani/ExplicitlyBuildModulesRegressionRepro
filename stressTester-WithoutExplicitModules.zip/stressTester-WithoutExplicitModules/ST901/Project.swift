import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST901",
    targets: [
        makeLibraryTarget(name: "ST901", dependencies: ["ST38", "ST44"])
    ]
)