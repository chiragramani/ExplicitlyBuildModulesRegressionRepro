import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST111",
    targets: [
        makeLibraryTarget(name: "ST111", dependencies: ["ST102", "ST92", "ST140", "ST20", "ST27", "ST90", "ST70", "ST23", "ST38", "ST161", "ST26", "ST74", "ST126", "ST89", "ST131", "ST4", "ST31", "ST34", "ST138", "ST87", "ST7", "ST96", "ST37", "ST187", "ST58", "ST192", "ST44", "ST61", "ST91", "ST139", "ST141", "ST223", "ST137"])
    ]
)