import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST300",
    targets: [
        makeLibraryTarget(name: "ST300", dependencies: ["ST102", "ST88", "ST44", "ST20", "ST594", "ST595", "ST137", "ST196", "ST60", "ST275", "ST4", "ST70", "ST543", "ST37", "ST417", "ST54", "ST89", "ST74", "ST131", "ST139", "ST584", "ST478", "ST150", "ST138", "ST148", "ST551", "ST92", "ST38", "ST90", "ST161", "ST483", "ST532", "ST96", "ST26", "ST142", "ST454", "ST484", "ST62", "ST27", "ST509", "ST376", "ST364", "ST136", "ST134"])
    ]
)