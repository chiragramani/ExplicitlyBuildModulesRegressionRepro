import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1149",
    targets: [
        makeLibraryTarget(name: "ST1149", dependencies: ["ST560", "ST559", "ST94", "ST38", "ST507"])
    ]
)