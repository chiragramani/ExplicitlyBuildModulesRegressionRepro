import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST520",
    targets: [
        makeLibraryTarget(name: "ST520", dependencies: ["ST70", "ST530", "ST4", "ST20", "ST531", "ST92", "ST89", "ST102", "ST96", "ST87", "ST26"])
    ]
)