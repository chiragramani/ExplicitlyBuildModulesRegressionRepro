import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST796",
    targets: [
        makeLibraryTarget(name: "ST796", dependencies: ["ST690", "ST26", "ST611", "ST20", "ST872", "ST214", "ST96", "ST18", "ST849", "ST851", "ST87", "ST92", "ST192", "ST102", "ST25", "ST70", "ST4", "ST74", "ST68", "ST799"])
    ]
)