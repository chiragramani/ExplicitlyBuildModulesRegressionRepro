import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST479",
    targets: [
        makeLibraryTarget(name: "ST479", dependencies: ["ST60", "ST214", "ST44", "ST87", "ST96", "ST70", "ST102", "ST716", "ST74", "ST24", "ST484", "ST38", "ST89", "ST195", "ST26", "ST635", "ST90", "ST81", "ST20", "ST92", "ST54"])
    ]
)