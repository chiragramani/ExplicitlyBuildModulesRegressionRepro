import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST354",
    targets: [
        makeLibraryTarget(name: "ST354", dependencies: ["ST26", "ST194", "ST138", "ST142", "ST455", "ST44", "ST96", "ST20", "ST131", "ST92", "ST276", "ST70", "ST89", "ST37", "ST102"])
    ]
)