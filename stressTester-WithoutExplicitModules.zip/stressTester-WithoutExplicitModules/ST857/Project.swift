import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST857",
    targets: [
        makeLibraryTarget(name: "ST857", dependencies: ["ST586", "ST530", "ST70", "ST87", "ST96", "ST20", "ST531", "ST54", "ST89", "ST92", "ST4", "ST102", "ST74", "ST26", "ST14", "ST850"])
    ]
)