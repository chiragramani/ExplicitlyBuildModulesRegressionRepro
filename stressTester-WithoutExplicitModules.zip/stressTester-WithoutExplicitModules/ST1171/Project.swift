import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1171",
    targets: [
        makeLibraryTarget(name: "ST1171", dependencies: ["ST529", "ST834"])
    ]
)