import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST69",
    targets: [
        makeLibraryTarget(name: "ST69", dependencies: ["ST13", "ST876", "ST874", "ST529", "ST1163", "ST729"])
    ]
)