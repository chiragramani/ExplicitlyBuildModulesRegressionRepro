import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST339",
    targets: [
        makeLibraryTarget(name: "ST339", dependencies: ["ST131", "ST22", "ST74", "ST152", "ST96", "ST138", "ST136", "ST92", "ST26"])
    ]
)