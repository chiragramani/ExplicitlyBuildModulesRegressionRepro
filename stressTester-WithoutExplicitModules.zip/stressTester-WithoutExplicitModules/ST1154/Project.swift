import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1154",
    targets: [
        makeLibraryTarget(name: "ST1154", dependencies: ["ST1155", "ST1141", "ST23", "ST94", "ST1156", "ST38", "ST26", "ST1142", "ST1157"])
    ]
)