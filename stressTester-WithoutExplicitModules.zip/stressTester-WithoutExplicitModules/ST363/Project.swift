import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST363",
    targets: [
        makeLibraryTarget(name: "ST363", dependencies: ["ST551", "ST26", "ST62", "ST150", "ST176", "ST76", "ST90", "ST139", "ST4", "ST138", "ST70", "ST23", "ST74", "ST136", "ST376", "ST102", "ST379", "ST290", "ST240", "ST92", "ST175", "ST196", "ST96", "ST20", "ST417", "ST89", "ST131", "ST148"])
    ]
)