import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1170",
    targets: [
        makeLibraryTarget(name: "ST1170", dependencies: ["ST507"])
    ]
)