import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST44",
    targets: [
        makeLibraryTarget(name: "ST44", dependencies: [])
    ]
)