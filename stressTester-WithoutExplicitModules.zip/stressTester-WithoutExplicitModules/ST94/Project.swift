import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST94",
    targets: [
        makeLibraryTarget(name: "ST94", dependencies: ["ST529", "ST93", "ST4", "ST773", "ST96", "ST80", "ST37"])
    ]
)