import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST286",
    targets: [
        makeLibraryTarget(name: "ST286", dependencies: ["ST76", "ST74", "ST142", "ST138", "ST136", "ST131", "ST92", "ST408", "ST509", "ST26"])
    ]
)