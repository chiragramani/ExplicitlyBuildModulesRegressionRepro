import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST68",
    targets: [
        makeLibraryTarget(name: "ST68", dependencies: ["ST587", "ST89", "ST264", "ST685", "ST74", "ST529", "ST25", "ST18", "ST665", "ST195", "ST686", "ST663", "ST591", "ST851", "ST532", "ST54", "ST653", "ST214", "ST610", "ST533", "ST675", "ST593", "ST699", "ST661", "ST44", "ST92", "ST676", "ST37", "ST652", "ST526", "ST527", "ST225", "ST525", "ST23", "ST657", "ST673", "ST655", "ST19", "ST524", "ST592", "ST186", "ST590", "ST87", "ST263", "ST682", "ST523", "ST659", "ST694", "ST4", "ST102", "ST70", "ST646", "ST690", "ST697", "ST684", "ST192", "ST674", "ST38", "ST468", "ST96", "ST20", "ST26"])
    ]
)