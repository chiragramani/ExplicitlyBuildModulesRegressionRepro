import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST748",
    targets: [
        makeLibraryTarget(name: "ST748", dependencies: ["ST74"])
    ]
)