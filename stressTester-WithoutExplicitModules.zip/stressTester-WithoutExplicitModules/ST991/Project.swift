import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST991",
    targets: [
        makeLibraryTarget(name: "ST991", dependencies: ["ST44", "ST38"])
    ]
)