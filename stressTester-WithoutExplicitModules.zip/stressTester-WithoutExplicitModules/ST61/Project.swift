import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST61",
    targets: [
        makeLibraryTarget(name: "ST61", dependencies: ["ST71", "ST74", "ST102", "ST26", "ST8", "ST70", "ST101", "ST96", "ST92", "ST4", "ST20", "ST89", "ST38", "ST44"])
    ]
)