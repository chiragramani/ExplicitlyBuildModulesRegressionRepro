import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST228",
    targets: [
        makeLibraryTarget(name: "ST228", dependencies: ["ST267", "ST70", "ST26", "ST92", "ST524", "ST20", "ST96", "ST593", "ST89", "ST102", "ST263", "ST68", "ST18", "ST25", "ST690", "ST611", "ST87", "ST4", "ST278", "ST214", "ST587", "ST590", "ST652", "ST38", "ST74", "ST666"])
    ]
)