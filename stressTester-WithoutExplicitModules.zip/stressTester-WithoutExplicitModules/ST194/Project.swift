import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST194",
    targets: [
        makeLibraryTarget(name: "ST194", dependencies: ["ST102", "ST20"])
    ]
)