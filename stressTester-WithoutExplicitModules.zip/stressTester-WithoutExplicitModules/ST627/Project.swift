import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST627",
    targets: [
        makeLibraryTarget(name: "ST627", dependencies: ["ST74", "ST422", "ST92", "ST38", "ST89", "ST87", "ST102", "ST70", "ST26", "ST20"])
    ]
)