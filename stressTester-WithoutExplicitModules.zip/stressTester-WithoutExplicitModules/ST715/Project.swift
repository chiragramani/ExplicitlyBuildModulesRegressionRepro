import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST715",
    targets: [
        makeLibraryTarget(name: "ST715", dependencies: ["ST596", "ST44", "ST80", "ST38", "ST189", "ST26", "ST4"])
    ]
)