import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST484",
    targets: [
        makeLibraryTarget(name: "ST484", dependencies: ["ST592", "ST192", "ST1164", "ST4", "ST501", "ST65", "ST189", "ST536", "ST38", "ST709", "ST44", "ST80", "ST596", "ST26"])
    ]
)