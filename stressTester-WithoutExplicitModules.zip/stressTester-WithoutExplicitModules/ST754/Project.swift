import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST754",
    targets: [
        makeLibraryTarget(name: "ST754", dependencies: ["ST828", "ST92", "ST26", "ST96", "ST4", "ST23", "ST74"])
    ]
)