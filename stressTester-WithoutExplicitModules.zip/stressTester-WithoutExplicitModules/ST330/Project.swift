import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST330",
    targets: [
        makeLibraryTarget(name: "ST330", dependencies: ["ST45", "ST131", "ST142", "ST62", "ST150", "ST53", "ST27", "ST20", "ST147", "ST267", "ST68", "ST513", "ST89", "ST376", "ST44", "ST74", "ST54", "ST37", "ST315", "ST96", "ST657", "ST32", "ST4", "ST26", "ST487", "ST92", "ST102", "ST70", "ST530", "ST137", "ST38", "ST192", "ST30", "ST534", "ST61", "ST154", "ST75", "ST23", "ST531", "ST139", "ST138", "ST214", "ST155"])
    ]
)