import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST984",
    targets: [
        makeLibraryTarget(name: "ST984", dependencies: ["ST38", "ST44"])
    ]
)