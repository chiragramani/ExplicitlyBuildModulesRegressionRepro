import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST922",
    targets: [
        makeLibraryTarget(name: "ST922", dependencies: ["ST44", "ST38"])
    ]
)