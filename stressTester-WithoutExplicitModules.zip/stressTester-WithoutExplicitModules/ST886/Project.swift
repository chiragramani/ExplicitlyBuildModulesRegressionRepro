import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST886",
    targets: [
        makeLibraryTarget(name: "ST886", dependencies: ["ST495", "ST20", "ST748", "ST92", "ST888", "ST90", "ST26", "ST187", "ST96", "ST23", "ST189", "ST74", "ST4", "ST191", "ST763", "ST102", "ST513", "ST6", "ST178"])
    ]
)