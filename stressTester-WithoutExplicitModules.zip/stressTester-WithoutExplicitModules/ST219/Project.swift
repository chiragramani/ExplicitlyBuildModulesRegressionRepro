import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST219",
    targets: [
        makeLibraryTarget(name: "ST219", dependencies: ["ST80", "ST4", "ST44", "ST26", "ST38"])
    ]
)