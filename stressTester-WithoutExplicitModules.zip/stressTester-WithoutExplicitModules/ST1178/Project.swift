import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1178",
    targets: [
        makeLibraryTarget(name: "ST1178", dependencies: [])
    ]
)