import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST645",
    targets: [
        makeLibraryTarget(name: "ST645", dependencies: ["ST529"])
    ]
)