import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST730",
    targets: [
        makeLibraryTarget(name: "ST730", dependencies: ["ST507"])
    ]
)