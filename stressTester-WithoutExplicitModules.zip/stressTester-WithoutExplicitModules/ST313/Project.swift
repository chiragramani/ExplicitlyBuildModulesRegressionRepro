import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST313",
    targets: [
        makeLibraryTarget(name: "ST313", dependencies: ["ST314", "ST315", "ST4", "ST65", "ST38", "ST145", "ST26", "ST391", "ST27", "ST96", "ST92", "ST512", "ST160", "ST150", "ST195", "ST20", "ST146", "ST54", "ST403", "ST102", "ST32", "ST176", "ST227", "ST89", "ST139", "ST74", "ST415", "ST70", "ST137", "ST138", "ST187", "ST99", "ST136", "ST142", "ST284", "ST19", "ST37", "ST509", "ST430", "ST192", "ST131", "ST23", "ST380", "ST87", "ST45", "ST75", "ST330"])
    ]
)