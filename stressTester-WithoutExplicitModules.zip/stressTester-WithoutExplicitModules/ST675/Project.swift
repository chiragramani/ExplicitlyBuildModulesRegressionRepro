import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST675",
    targets: [
        makeLibraryTarget(name: "ST675", dependencies: ["ST92", "ST214"])
    ]
)