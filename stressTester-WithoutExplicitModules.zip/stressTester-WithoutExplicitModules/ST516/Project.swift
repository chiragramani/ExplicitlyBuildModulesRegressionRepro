import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST516",
    targets: [
        makeLibraryTarget(name: "ST516", dependencies: ["ST177", "ST49", "ST89", "ST515", "ST26", "ST90", "ST495", "ST70", "ST20", "ST178", "ST92", "ST102", "ST513", "ST74", "ST96", "ST23", "ST62", "ST4", "ST179"])
    ]
)