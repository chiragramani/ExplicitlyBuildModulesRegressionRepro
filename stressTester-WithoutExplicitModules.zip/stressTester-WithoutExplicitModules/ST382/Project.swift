import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST382",
    targets: [
        makeLibraryTarget(name: "ST382", dependencies: ["ST264", "ST281", "ST30", "ST14", "ST96", "ST225", "ST374", "ST131", "ST68", "ST54", "ST4", "ST44", "ST150", "ST267", "ST367", "ST102", "ST214", "ST282", "ST89", "ST92", "ST20", "ST585", "ST283", "ST213", "ST138", "ST84", "ST586", "ST87", "ST587", "ST38", "ST26", "ST524", "ST261"])
    ]
)