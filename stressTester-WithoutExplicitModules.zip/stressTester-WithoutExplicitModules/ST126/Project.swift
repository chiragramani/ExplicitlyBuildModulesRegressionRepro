import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST126",
    targets: [
        makeLibraryTarget(name: "ST126", dependencies: ["ST306", "ST264", "ST567", "ST312", "ST568", "ST428", "ST373", "ST334", "ST336", "ST569", "ST213", "ST23", "ST320", "ST137", "ST258", "ST570", "ST318", "ST349", "ST26", "ST571", "ST241", "ST572", "ST172", "ST313", "ST38", "ST330", "ST145", "ST293", "ST524", "ST394", "ST511", "ST250", "ST75", "ST383", "ST249", "ST45", "ST296", "ST150", "ST322", "ST84", "ST220", "ST573", "ST412", "ST574", "ST556", "ST382", "ST20", "ST214", "ST146", "ST54", "ST74", "ST291", "ST176", "ST363", "ST381", "ST234", "ST11", "ST287", "ST323", "ST154", "ST390", "ST161", "ST575", "ST91", "ST340", "ST305", "ST27", "ST576", "ST310", "ST173", "ST267", "ST174", "ST289", "ST367", "ST577", "ST348", "ST175", "ST342", "ST403", "ST136", "ST155", "ST32", "ST327", "ST369", "ST149", "ST578", "ST579", "ST374", "ST297", "ST37", "ST247", "ST352", "ST391", "ST223", "ST416", "ST270", "ST449", "ST300", "ST341", "ST62", "ST30", "ST139", "ST314", "ST217", "ST452", "ST89", "ST131", "ST343", "ST290", "ST447", "ST309", "ST4", "ST144", "ST580", "ST92", "ST192", "ST68", "ST335", "ST311", "ST321", "ST295", "ST96", "ST138", "ST581", "ST551", "ST347", "ST307", "ST357", "ST34", "ST582", "ST376", "ST90", "ST261", "ST397"])
    ]
)