import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST20",
    targets: [
        makeLibraryTarget(name: "ST20", dependencies: ["ST810", "ST26", "ST532", "ST1166", "ST74", "ST87", "ST92", "ST529", "ST795", "ST531", "ST186", "ST4", "ST530", "ST196", "ST811", "ST187", "ST199", "ST96", "ST70"])
    ]
)