import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST938",
    targets: [
        makeLibraryTarget(name: "ST938", dependencies: ["ST44", "ST38"])
    ]
)