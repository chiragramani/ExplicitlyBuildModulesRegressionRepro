import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST978",
    targets: [
        makeLibraryTarget(name: "ST978", dependencies: ["ST38", "ST44"])
    ]
)