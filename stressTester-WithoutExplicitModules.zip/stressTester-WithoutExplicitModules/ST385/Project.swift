import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST385",
    targets: [
        makeLibraryTarget(name: "ST385", dependencies: ["ST70", "ST96", "ST26", "ST455", "ST142", "ST75", "ST32", "ST131", "ST20", "ST92", "ST241", "ST74", "ST87", "ST192", "ST251", "ST38", "ST102", "ST89"])
    ]
)