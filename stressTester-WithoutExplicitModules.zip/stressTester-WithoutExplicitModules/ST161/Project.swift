import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST161",
    targets: [
        makeLibraryTarget(name: "ST161", dependencies: ["ST37", "ST96", "ST4", "ST190", "ST26"])
    ]
)