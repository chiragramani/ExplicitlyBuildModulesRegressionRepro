import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST572",
    targets: [
        makeLibraryTarget(name: "ST572", dependencies: ["ST26", "ST138", "ST92", "ST131", "ST96", "ST139"])
    ]
)