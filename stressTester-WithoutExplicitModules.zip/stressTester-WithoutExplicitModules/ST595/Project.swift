import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST595",
    targets: [
        makeLibraryTarget(name: "ST595", dependencies: ["ST513", "ST89", "ST62", "ST221", "ST88", "ST161", "ST586", "ST596", "ST225", "ST282", "ST43", "ST96", "ST583", "ST597", "ST281", "ST242", "ST58", "ST454", "ST154", "ST6", "ST196", "ST253", "ST593", "ST14", "ST26", "ST37", "ST275", "ST220", "ST49", "ST598", "ST70", "ST92", "ST599", "ST23", "ST172", "ST600", "ST267", "ST87", "ST95", "ST44", "ST187", "ST20", "ST192", "ST38", "ST259", "ST191", "ST90", "ST102", "ST452", "ST74", "ST264", "ST601", "ST543", "ST602", "ST68", "ST494", "ST584", "ST214", "ST76", "ST271", "ST61", "ST422", "ST590", "ST67", "ST592", "ST176", "ST81", "ST195", "ST54", "ST535", "ST4"])
    ]
)