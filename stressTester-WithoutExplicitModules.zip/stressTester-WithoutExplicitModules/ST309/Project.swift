import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST309",
    targets: [
        makeLibraryTarget(name: "ST309", dependencies: ["ST74", "ST531", "ST89", "ST20", "ST4", "ST102", "ST287", "ST138", "ST530", "ST602", "ST27", "ST70", "ST37", "ST96", "ST87", "ST26", "ST150", "ST131", "ST391", "ST139", "ST92", "ST517"])
    ]
)