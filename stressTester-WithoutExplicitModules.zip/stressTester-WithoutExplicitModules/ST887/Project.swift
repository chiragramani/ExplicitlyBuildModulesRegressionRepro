import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST887",
    targets: [
        makeLibraryTarget(name: "ST887", dependencies: ["ST748", "ST96", "ST749", "ST74", "ST889", "ST48", "ST80", "ST93"])
    ]
)