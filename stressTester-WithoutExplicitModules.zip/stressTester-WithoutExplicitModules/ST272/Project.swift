import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST272",
    targets: [
        makeLibraryTarget(name: "ST272", dependencies: ["ST38", "ST26", "ST4", "ST44", "ST80"])
    ]
)