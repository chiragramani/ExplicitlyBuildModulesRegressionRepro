import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST87",
    targets: [
        makeLibraryTarget(name: "ST87", dependencies: ["ST96"])
    ]
)