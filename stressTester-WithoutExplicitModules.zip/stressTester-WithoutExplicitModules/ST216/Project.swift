import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST216",
    targets: [
        makeLibraryTarget(name: "ST216", dependencies: ["ST74", "ST38", "ST26", "ST4", "ST92", "ST44", "ST65"])
    ]
)