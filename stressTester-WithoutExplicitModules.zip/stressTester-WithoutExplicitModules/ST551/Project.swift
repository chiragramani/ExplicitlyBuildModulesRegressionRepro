import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST551",
    targets: [
        makeLibraryTarget(name: "ST551", dependencies: ["ST178", "ST192", "ST20", "ST26", "ST23", "ST4", "ST583", "ST187", "ST62", "ST96", "ST74", "ST513", "ST92"])
    ]
)