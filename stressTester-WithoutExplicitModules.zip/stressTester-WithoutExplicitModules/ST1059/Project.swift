import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1059",
    targets: [
        makeLibraryTarget(name: "ST1059", dependencies: ["ST44", "ST38"])
    ]
)