import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST610",
    targets: [
        makeLibraryTarget(name: "ST610", dependencies: ["ST214", "ST89", "ST524", "ST600", "ST92"])
    ]
)