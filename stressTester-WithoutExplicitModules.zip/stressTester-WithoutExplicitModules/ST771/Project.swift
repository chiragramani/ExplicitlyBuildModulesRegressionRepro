import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST771",
    targets: [
        makeLibraryTarget(name: "ST771", dependencies: ["ST44", "ST96"])
    ]
)