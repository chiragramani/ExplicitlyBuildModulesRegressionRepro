import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1100",
    targets: [
        makeLibraryTarget(name: "ST1100", dependencies: ["ST44", "ST38"])
    ]
)