import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST581",
    targets: [
        makeLibraryTarget(name: "ST581", dependencies: ["ST196", "ST70", "ST131", "ST138", "ST20", "ST74", "ST26", "ST136", "ST92", "ST89", "ST87", "ST139", "ST102"])
    ]
)