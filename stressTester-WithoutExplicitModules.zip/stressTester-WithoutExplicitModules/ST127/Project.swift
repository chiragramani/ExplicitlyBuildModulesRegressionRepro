import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST127",
    targets: [
        makeLibraryTarget(name: "ST127", dependencies: ["ST613", "ST37", "ST263", "ST278", "ST614", "ST95", "ST68", "ST80", "ST20", "ST214", "ST13", "ST92", "ST215", "ST615", "ST26", "ST83", "ST93", "ST267", "ST89", "ST74", "ST96", "ST242", "ST73", "ST616", "ST224", "ST38", "ST276", "ST289", "ST292", "ST301", "ST319", "ST325", "ST330", "ST335", "ST343", "ST344", "ST345", "ST356", "ST357", "ST365", "ST367", "ST380", "ST381", "ST617", "ST405", "ST408", "ST411", "ST130", "ST131", "ST138", "ST142", "ST150", "ST618", "ST153", "ST154", "ST155", "ST422", "ST161", "ST162", "ST168", "ST170", "ST171", "ST174", "ST180", "ST428", "ST97", "ST23", "ST29", "ST102", "ST57", "ST61", "ST619", "ST54", "ST442", "ST620", "ST30", "ST472", "ST478", "ST479", "ST480", "ST60", "ST482", "ST483", "ST43", "ST67", "ST47", "ST36", "ST487", "ST488", "ST282", "ST281", "ST10", "ST621", "ST622", "ST597", "ST11", "ST76", "ST623", "ST624", "ST45"])
    ]
)