import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST892",
    targets: [
        makeLibraryTarget(name: "ST892", dependencies: ["ST38", "ST44"])
    ]
)