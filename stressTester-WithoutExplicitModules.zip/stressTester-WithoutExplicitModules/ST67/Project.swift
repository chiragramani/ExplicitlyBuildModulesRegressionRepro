import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST67",
    targets: [
        makeLibraryTarget(name: "ST67", dependencies: ["ST70", "ST837", "ST76", "ST71", "ST4", "ST90", "ST20", "ST720", "ST441", "ST98", "ST192", "ST102", "ST530", "ST89", "ST96", "ST424", "ST161", "ST615", "ST531", "ST61", "ST43", "ST26", "ST37", "ST38", "ST74", "ST54", "ST418", "ST87", "ST92", "ST44"])
    ]
)