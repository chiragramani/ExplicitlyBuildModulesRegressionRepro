import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST776",
    targets: [
        makeLibraryTarget(name: "ST776", dependencies: ["ST587", "ST278", "ST652", "ST214", "ST25", "ST102", "ST657", "ST666", "ST611", "ST186", "ST92", "ST96", "ST524", "ST23", "ST89", "ST74", "ST692", "ST18", "ST70", "ST20", "ST68", "ST690", "ST87", "ST26"])
    ]
)