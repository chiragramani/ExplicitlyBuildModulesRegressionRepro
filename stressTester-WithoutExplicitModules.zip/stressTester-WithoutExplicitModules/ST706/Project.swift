import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST706",
    targets: [
        makeLibraryTarget(name: "ST706", dependencies: ["ST92"])
    ]
)