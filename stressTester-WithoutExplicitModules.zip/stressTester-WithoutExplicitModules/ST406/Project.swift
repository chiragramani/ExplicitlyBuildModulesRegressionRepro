import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST406",
    targets: [
        makeLibraryTarget(name: "ST406", dependencies: ["ST90", "ST192", "ST32", "ST20", "ST23", "ST425", "ST150", "ST96", "ST74", "ST38", "ST299", "ST378", "ST89", "ST161", "ST131", "ST53", "ST734", "ST26", "ST102", "ST37", "ST138", "ST70", "ST75", "ST452", "ST4", "ST187", "ST92"])
    ]
)