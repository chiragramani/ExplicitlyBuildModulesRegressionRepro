import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1114",
    targets: [
        makeLibraryTarget(name: "ST1114", dependencies: ["ST44", "ST38"])
    ]
)