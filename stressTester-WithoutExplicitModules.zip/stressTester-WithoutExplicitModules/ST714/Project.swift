import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST714",
    targets: [
        makeLibraryTarget(name: "ST714", dependencies: ["ST596", "ST44", "ST26", "ST38", "ST4", "ST80"])
    ]
)