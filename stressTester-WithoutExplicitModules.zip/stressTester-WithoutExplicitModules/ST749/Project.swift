import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST749",
    targets: [
        makeLibraryTarget(name: "ST749", dependencies: ["ST196", "ST74", "ST93", "ST80", "ST187", "ST4", "ST44", "ST876", "ST96"])
    ]
)