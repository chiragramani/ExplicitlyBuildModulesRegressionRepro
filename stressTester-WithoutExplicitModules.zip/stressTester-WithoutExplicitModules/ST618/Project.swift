import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST618",
    targets: [
        makeLibraryTarget(name: "ST618", dependencies: ["ST92", "ST26", "ST74", "ST131", "ST625"])
    ]
)