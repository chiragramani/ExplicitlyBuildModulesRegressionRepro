import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST505",
    targets: [
        makeLibraryTarget(name: "ST505", dependencies: ["ST38", "ST507", "ST559", "ST94"])
    ]
)