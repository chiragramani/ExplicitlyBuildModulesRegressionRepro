import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST289",
    targets: [
        makeLibraryTarget(name: "ST289", dependencies: ["ST214", "ST529", "ST97", "ST131", "ST150", "ST645", "ST151", "ST15", "ST36", "ST224", "ST89", "ST38", "ST18", "ST96", "ST29", "ST487", "ST524", "ST130", "ST25", "ST167", "ST646", "ST357", "ST37", "ST14", "ST74", "ST87", "ST647", "ST70", "ST648", "ST168", "ST142", "ST138", "ST485", "ST344", "ST649", "ST102", "ST26", "ST20", "ST282", "ST23", "ST256", "ST624", "ST486", "ST68", "ST92", "ST54", "ST196", "ST488", "ST61", "ST4", "ST612", "ST587"])
    ]
)