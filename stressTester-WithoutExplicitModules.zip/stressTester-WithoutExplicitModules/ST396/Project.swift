import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST396",
    targets: [
        makeLibraryTarget(name: "ST396", dependencies: ["ST497", "ST38", "ST89", "ST92", "ST96", "ST498", "ST245", "ST499", "ST54", "ST20", "ST102", "ST140"])
    ]
)