import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST33",
    targets: [
        makeLibraryTarget(name: "ST33", dependencies: ["ST20", "ST89", "ST75", "ST54", "ST74", "ST102", "ST53", "ST92", "ST26", "ST32", "ST96", "ST192"])
    ]
)