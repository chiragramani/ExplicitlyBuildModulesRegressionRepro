import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST29",
    targets: [
        makeLibraryTarget(name: "ST29", dependencies: ["ST96", "ST69", "ST37", "ST38", "ST74", "ST83", "ST170", "ST187", "ST4", "ST26", "ST97", "ST89", "ST718", "ST186", "ST92", "ST82"])
    ]
)