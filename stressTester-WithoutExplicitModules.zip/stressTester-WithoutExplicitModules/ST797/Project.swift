import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST797",
    targets: [
        makeLibraryTarget(name: "ST797", dependencies: ["ST641", "ST44", "ST96", "ST74", "ST214", "ST92", "ST524", "ST102", "ST26", "ST4", "ST533", "ST187", "ST89", "ST99", "ST68"])
    ]
)