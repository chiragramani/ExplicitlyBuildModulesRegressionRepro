import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST315",
    targets: [
        makeLibraryTarget(name: "ST315", dependencies: ["ST176", "ST192", "ST102", "ST145", "ST44", "ST87", "ST569", "ST26", "ST227", "ST131", "ST92", "ST323", "ST23", "ST138", "ST27", "ST150", "ST139", "ST20", "ST89", "ST4", "ST74", "ST70", "ST531", "ST534", "ST146", "ST96"])
    ]
)