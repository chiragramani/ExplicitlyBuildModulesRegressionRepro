import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST912",
    targets: [
        makeLibraryTarget(name: "ST912", dependencies: ["ST44", "ST38"])
    ]
)