import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST132",
    targets: [
        makeLibraryTarget(name: "ST132", dependencies: ["ST78", "ST9", "ST26", "ST170", "ST23", "ST74", "ST38", "ST187", "ST96", "ST166"])
    ]
)