import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST151",
    targets: [
        makeLibraryTarget(name: "ST151", dependencies: ["ST74", "ST92", "ST102", "ST96", "ST20", "ST26", "ST89", "ST4"])
    ]
)