import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST1179",
    targets: [
        makeLibraryTarget(name: "ST1179", dependencies: [])
    ]
)