import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST336",
    targets: [
        makeLibraryTarget(name: "ST336", dependencies: ["ST361", "ST38", "ST74", "ST142", "ST416", "ST88", "ST26", "ST80", "ST91", "ST290", "ST131", "ST405", "ST549", "ST23", "ST550", "ST187", "ST148", "ST376", "ST20", "ST391", "ST45", "ST4", "ST93", "ST136", "ST551", "ST554", "ST139", "ST425", "ST513", "ST37", "ST102", "ST417", "ST383", "ST330", "ST314", "ST258", "ST178", "ST386", "ST62", "ST192", "ST24", "ST137", "ST528", "ST240", "ST589", "ST49", "ST161", "ST138", "ST89", "ST96", "ST176", "ST70", "ST150", "ST90", "ST87", "ST92"])
    ]
)