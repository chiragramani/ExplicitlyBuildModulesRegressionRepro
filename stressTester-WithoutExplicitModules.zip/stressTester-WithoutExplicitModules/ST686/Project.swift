import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST686",
    targets: [
        makeLibraryTarget(name: "ST686", dependencies: ["ST92"])
    ]
)