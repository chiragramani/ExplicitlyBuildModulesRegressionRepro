import ProjectDescription
import ProjectDescriptionHelpers

let project = Project(
    name: "ST422",
    targets: [
        makeLibraryTarget(name: "ST422", dependencies: ["ST100", "ST74", "ST28", "ST80", "ST44", "ST92", "ST37", "ST102", "ST48", "ST96", "ST154", "ST196", "ST4", "ST38", "ST187", "ST26", "ST93", "ST201", "ST95", "ST83", "ST61"])
    ]
)